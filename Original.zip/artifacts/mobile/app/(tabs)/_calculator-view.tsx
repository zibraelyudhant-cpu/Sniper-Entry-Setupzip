import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as Clipboard from 'expo-clipboard';
import * as Linking from 'expo-linking';
import {
  Animated,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

import { useLocalSearchParams } from 'expo-router';
import { MENU_COLORS } from '@/constants/theme';

const ACCENT = MENU_COLORS.calculator;

// ─── Formatters ───────────────────────────────────────────────────────────────

function formatPrice(price: number): string {
  let result: string;
  if (price >= 10000) result = price.toFixed(2);
  else if (price >= 100) result = price.toFixed(2);
  else if (price >= 1) result = price.toFixed(4);
  else result = price.toFixed(6);
  // Ganti titik dengan koma sebagai desimal
  return result.replace('.', ',');
}

function formatPnl(pnl: number): string {
  const abs = Math.abs(pnl);
  const sign = pnl >= 0 ? '+' : '-';
  return `${sign}${abs.toFixed(2)}`;
}

// ─── Sub-components ───────────────────────────────────────────────────────────

interface SectionProps { title: string; children: React.ReactNode }
function Section({ title, children }: SectionProps) {
  const colors = useColors();
  return (
    <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>{title}</Text>
      {children}
    </View>
  );
}

// ─── Risk Bar — animasi warna & lebar mengikuti tingkat leverage ──────────────
function RiskBar({ leverage, maxLeverage }: { leverage: number; maxLeverage: number }) {
  const colors = useColors();
  const pct = Math.min((leverage / maxLeverage) * 100, 100);
  const widthAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(widthAnim, { toValue: pct, duration: 250, useNativeDriver: false }).start();
  }, [pct, widthAnim]);

  const level = pct < 40 ? 'aman' : pct < 70 ? 'sedang' : 'tinggi';
  const color = level === 'aman' ? colors.bullish : level === 'sedang' ? colors.gold : colors.bearish;
  const label = level === 'aman' ? 'RISIKO: AMAN' : level === 'sedang' ? 'RISIKO: SEDANG' : 'RISIKO: TINGGI';

  return (
    <View style={{ marginTop: 10 }}>
      <View style={{ height: 6, borderRadius: 3, backgroundColor: colors.background, overflow: 'hidden' }}>
        <Animated.View
          style={{
            height: '100%',
            borderRadius: 3,
            backgroundColor: color,
            width: widthAnim.interpolate({ inputRange: [0, 100], outputRange: ['0%', '100%'] }),
          }}
        />
      </View>
      <Text style={{ fontSize: 9, color, marginTop: 4, fontFamily: 'Inter_600SemiBold', letterSpacing: 0.5 }}>
        {label}
      </Text>
    </View>
  );
}

interface RowProps { label: string; value: string; valueColor?: string; mono?: boolean }
function Row({ label, value, valueColor, mono }: RowProps) {
  const colors = useColors();
  return (
    <View style={styles.row}>
      <Text style={[styles.rowLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.rowValue, { color: valueColor ?? colors.foreground, fontFamily: mono ? 'Inter_600SemiBold' : 'Inter_500Medium' }]}>
        {value}
      </Text>
    </View>
  );
}

// ─── Max Leverage per koin (approksimasi tier Binance Futures) ────────────────
// PENTING: Binance gak punya endpoint publik buat max leverage per simbol
// (endpoint aslinya /fapi/v1/leverageBracket butuh API key). Ini tabel manual
// berdasarkan tier likuiditas & cap yang umum dipublikasikan Binance.
// Default fallback 20x buat koin yang gak ada di daftar (konservatif, aman).
const MAX_LEVERAGE_TABLE: Record<string, number> = {
  BTCUSDT: 125, ETHUSDT: 125,
  BNBUSDT: 100,
  SOLUSDT: 75, XRPUSDT: 75, DOGEUSDT: 75, ADAUSDT: 75,
  AVAXUSDT: 50, LINKUSDT: 50, LTCUSDT: 50, DOTUSDT: 50, TRXUSDT: 50,
  NEARUSDT: 50, ATOMUSDT: 50, UNIUSDT: 50, ETCUSDT: 50, FILUSDT: 50,
  APTUSDT: 50, ARBUSDT: 50, OPUSDT: 50, SUIUSDT: 50, INJUSDT: 50,
};
function getMaxLeverage(sym: string): number {
  return MAX_LEVERAGE_TABLE[sym.toUpperCase()] ?? 20;
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function CalculatorScreen({ embedded = false }: { embedded?: boolean } = {}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{
    entryPrice?: string;
    stopLoss?: string;
    takeProfit1?: string;
    takeProfit2?: string;
    symbol?: string;
    direction?: string;
    source?: string;
  }>();

  const roundParam = (val: string | undefined): string => {
    const n = parseFloat(val ?? '');
    if (isNaN(n)) return '';
    if (n >= 10000) return n.toFixed(2);
    if (n >= 100) return n.toFixed(2);
    if (n >= 1) return n.toFixed(4);
    return n.toFixed(6);
  };
  const [entryStr, setEntryStr] = useState(() => roundParam(params.entryPrice));
  const [slStr, setSlStr] = useState(() => roundParam(params.stopLoss));
  const [tp1Str, setTp1Str] = useState(() => roundParam(params.takeProfit1));
  const [tp2Str, setTp2Str] = useState(() => roundParam(params.takeProfit2));
  const entryPrice = parseFloat(entryStr) || 0;
  const stopLoss = parseFloat(slStr) || 0;
  const takeProfit1 = parseFloat(tp1Str) || 0;
  const takeProfit2 = parseFloat(tp2Str) || 0;
  const symbol = params.symbol ?? '';
  const bias = (params.direction === 'bearish' ? 'bearish' : 'bullish') as 'bullish' | 'bearish';
  const source = params.source ?? '';
  const base = symbol.replace('USDT', '') || 'Coin';
  const hasPrices = entryPrice > 0 && stopLoss > 0 && takeProfit1 > 0;

  // ─── Input state ────────────────────────────────────────────────────────────
  const [modalStr, setModalStr] = useState('100');
  const [contractsStr, setContractsStr] = useState('');
  const [leverageStr, setLeverageStr] = useState('10');
  const [marginMode, setMarginMode] = useState<'cross' | 'isolated'>('isolated');
  const [lastEdited, setLastEdited] = useState<'modal' | 'contracts'>('modal');
  const [accountBalanceStr, setAccountBalanceStr] = useState('1000'); // buat risk-based sizing

  const [side, setSide] = useState<'long' | 'short'>(bias === 'bullish' ? 'long' : 'short');

  // Reset semua field kalau params berubah (ganti koin dari Menu 2)
  useEffect(() => {
    setEntryStr(roundParam(params.entryPrice));
    setSlStr(roundParam(params.stopLoss));
    setTp1Str(roundParam(params.takeProfit1));
    setTp2Str(roundParam(params.takeProfit2));
    if (params.direction) {
      setSide(params.direction === 'bearish' ? 'short' : 'long');
    }
  }, [params.entryPrice, params.stopLoss, params.takeProfit1, params.takeProfit2, params.symbol, params.direction]);
  const maxLeverage = getMaxLeverage(symbol);
  const leverage = Math.min(Math.max(parseFloat(leverageStr) || 1, 1), maxLeverage);
  const showLevWarning = leverage > 20;

  // ─── Handlers ───────────────────────────────────────────────────────────────
  const handleModalChange = useCallback((val: string) => {
    setModalStr(val);
    setLastEdited('modal');
    const m = parseFloat(val);
    if (!isNaN(m) && m > 0 && entryPrice > 0 && leverage > 0) {
      setContractsStr(((m * leverage) / entryPrice).toFixed(6));
    }
  }, [entryPrice, leverage]);

  const handleContractsChange = useCallback((val: string) => {
    setContractsStr(val);
    setLastEdited('contracts');
    const c = parseFloat(val);
    if (!isNaN(c) && c > 0 && entryPrice > 0 && leverage > 0) {
      setModalStr(((c * entryPrice) / leverage).toFixed(2));
    }
  }, [entryPrice, leverage]);

  const handleLeverageChange = useCallback((val: string) => {
    setLeverageStr(val);
    const lev = Math.min(Math.max(parseFloat(val) || 1, 1), 125);
    if (lastEdited === 'modal') {
      const m = parseFloat(modalStr);
      if (!isNaN(m) && m > 0 && entryPrice > 0) {
        setContractsStr(((m * lev) / entryPrice).toFixed(6));
      }
    } else {
      const c = parseFloat(contractsStr);
      if (!isNaN(c) && c > 0 && entryPrice > 0) {
        setModalStr(((c * entryPrice) / lev).toFixed(2));
      }
    }
  }, [lastEdited, modalStr, contractsStr, entryPrice]);

  // ─── Risk-based sizing (ala ICT — risk per trade 0.5-1% dari saldo akun) ───
  // Ngitung mundur: dari jarak Entry-SL + persentase risk, dapetin ukuran posisi
  // yang bikin kerugian saat SL kena = persis risk% dari saldo, bukan asal-asalan.
  const applyRiskPreset = useCallback((riskPct: number) => {
    if (!hasPrices || leverage <= 0) return;
    const balance = parseFloat(accountBalanceStr) || 0;
    const priceDistance = Math.abs(entryPrice - stopLoss);
    if (balance <= 0 || priceDistance <= 0) return;

    const riskAmount = balance * (riskPct / 100);
    const contracts = riskAmount / priceDistance;
    const modal = (contracts * entryPrice) / leverage;

    setContractsStr(contracts.toFixed(6));
    setModalStr(modal.toFixed(2));
    setLastEdited('modal');
  }, [hasPrices, leverage, accountBalanceStr, entryPrice, stopLoss]);


  // ─── Calculations ────────────────────────────────────────────────────────────
  const calc = useMemo(() => {
    if (!hasPrices || leverage <= 0) return null;

    const modal = parseFloat(modalStr) || 0;
    if (modal <= 0) return null;

    const contracts = (modal * leverage) / entryPrice;
    const initialMargin = modal; // = (contracts * entryPrice) / leverage
    const dir = side === 'long' ? 1 : -1;
    const mmRate = 0.005;

    const pnlSL  = contracts * (stopLoss - entryPrice) * dir;
    const pnlTP1 = contracts * (takeProfit1 - entryPrice) * dir;
    const pnlTP2 = contracts * (takeProfit2 - entryPrice) * dir;

    const roeSL  = initialMargin > 0 ? (pnlSL  / initialMargin) * 100 : 0;
    const roeTP1 = initialMargin > 0 ? (pnlTP1 / initialMargin) * 100 : 0;
    const roeTP2 = initialMargin > 0 ? (pnlTP2 / initialMargin) * 100 : 0;

    const liqCross = bias === 'bullish'
      ? entryPrice * (1 - 1 / leverage)
      : entryPrice * (1 + 1 / leverage);
    const liqIsolated = bias === 'bullish'
      ? entryPrice * (1 - 1 / leverage + mmRate)
      : entryPrice * (1 + 1 / leverage - mmRate);
    const liqPrice = marginMode === 'cross' ? liqCross : liqIsolated;

    const liqDist = Math.abs((liqPrice - entryPrice) / entryPrice) * 100;

    return { contracts, initialMargin, pnlSL, pnlTP1, pnlTP2, roeSL, roeTP1, roeTP2, liqPrice, liqDist };
  }, [modalStr, leverage, entryPrice, stopLoss, takeProfit1, takeProfit2, bias, marginMode, hasPrices]);

  const liqColor = !calc ? colors.mutedForeground
    : calc.liqDist > 20 ? colors.bullish
    : calc.liqDist > 10 ? colors.warning
    : colors.bearish;

  const topPadding = embedded ? 12 : insets.top + (Platform.OS === 'web' ? 67 : 0);
  const bottomPadding = insets.bottom + 80;

  return (
      <KeyboardAvoidingView
        style={[styles.container, { backgroundColor: colors.background }]}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPadding + 12, borderBottomColor: colors.border, backgroundColor: colors.background }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Kalkulator PnL</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Text style={[styles.headerSub, { color: colors.mutedForeground }]}>
            {symbol ? symbol.replace('USDT', '/USDT') : 'Futures Perpetual'}
          </Text>
          {symbol && source ? (
            <View style={{ flexDirection: 'row', gap: 6 }}>
              <View style={{
                paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20,
                backgroundColor: side === 'long' ? '#16A34A22' : '#DC262622',
                borderWidth: 1,
                borderColor: side === 'long' ? '#16A34A' : '#DC2626',
              }}>
                <Text style={{ fontSize: 11, fontWeight: '600', color: side === 'long' ? '#16A34A' : '#DC2626' }}>
                  {side === 'long' ? 'BUY' : 'SELL'}
                </Text>
              </View>
              <View style={{
                paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20,
                backgroundColor: '#534AB722',
                borderWidth: 1, borderColor: '#534AB7',
              }}>
                <Text style={{ fontSize: 11, fontWeight: '500', color: '#7F77DD' }}>
                  {source === 'sniper' ? 'Sniper' : source === 'sniper_rsi2' ? 'RSI Connors' : source === 'scalping' ? 'Scalping' : source}
                </Text>
              </View>
            </View>
          ) : null}
        </View>
      </View>

        <ScrollView
          contentContainerStyle={{ padding: 16, paddingBottom: bottomPadding }}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          style={{ flex: 1 }}
        >
        {/* ── LONG / SHORT TOGGLE ────────────────────────────────────────── */}
        <View style={[styles.sideToggle, { borderColor: colors.border }]}>
          <Pressable
            onPress={() => setSide('long')}
            style={[styles.sideBtn, side === 'long' && { backgroundColor: '#16A34A' }]}
          >
            <Text style={[styles.sideBtnText, { color: side === 'long' ? '#fff' : colors.mutedForeground }]}>
              ↗ Long
            </Text>
          </Pressable>
          <Pressable
            onPress={() => setSide('short')}
            style={[styles.sideBtn, side === 'short' && { backgroundColor: '#DC2626' }]}
          >
            <Text style={[styles.sideBtnText, { color: side === 'short' ? '#fff' : colors.mutedForeground }]}>
              ↘ Short
            </Text>
          </Pressable>
        </View>

        {/* ── LEVERAGE ───────────────────────────────────────────────────── */}
        <Section title="LEVERAGE">
          <View style={styles.levRow}>
            <View>
              <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Leverage</Text>
              <Text style={{ fontSize: 10, color: colors.mutedForeground, marginTop: 2 }}>
                Maks {maxLeverage}x {symbol ? `untuk ${base}` : '(default umum — buka dari menu lain untuk data akurat)'}
              </Text>
            </View>
            <View style={styles.inputRight}>
              <TextInput
                style={[styles.inputField, { color: colors.foreground }]}
                keyboardType="number-pad"
                value={leverageStr}
                onChangeText={handleLeverageChange}
                placeholder="10"
                placeholderTextColor={colors.mutedForeground}
                selectTextOnFocus
              />
              <Text style={[styles.inputUnit, { color: colors.mutedForeground }]}>x</Text>
            </View>
          </View>
          <View style={styles.presets}>
            {[1, 5, 10, 20, Math.round(maxLeverage / 2), maxLeverage]
              .filter((p, i, arr) => p <= maxLeverage && arr.indexOf(p) === i)
              .sort((a, b) => a - b)
              .map(p => (
              <Pressable
                key={p}
                onPress={() => handleLeverageChange(String(p))}
                style={[styles.presetBtn, {
                  borderColor: colors.border,
                  backgroundColor: leverage === p ? ACCENT : colors.background,
                }]}
              >
                <Text style={[styles.presetText, { color: leverage === p ? '#fff' : colors.mutedForeground }]}>
                  {p}x
                </Text>
              </Pressable>
            ))}
          </View>
          <RiskBar leverage={leverage} maxLeverage={maxLeverage} />
          {showLevWarning && (
            <Text style={{ fontSize: 12, color: '#F59E0B', marginTop: 8 }}>
              ⚠ Leverage tinggi meningkatkan risiko likuidasi
            </Text>
          )}
        </Section>

        {/* ── RISK SIZING (konsep ICT: risk 0.5-1% per trade) ─────────────── */}
        {hasPrices && (
          <Section title="RISK SIZING">
            <View style={[styles.inputRow, { borderColor: colors.border }]}>
              <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Saldo Akun</Text>
              <View style={styles.inputRight}>
                <TextInput
                  style={[styles.inputField, { color: colors.foreground }]}
                  keyboardType="decimal-pad"
                  value={accountBalanceStr}
                  onChangeText={setAccountBalanceStr}
                  placeholder="1000"
                  placeholderTextColor={colors.mutedForeground}
                  selectTextOnFocus
                />
                <Text style={[styles.inputUnit, { color: colors.mutedForeground }]}>USDT</Text>
              </View>
            </View>
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
              <Pressable
                onPress={() => applyRiskPreset(0.5)}
                style={({ pressed }) => [{ flex: 1, paddingVertical: 10, borderRadius: 8, borderWidth: 1, borderColor: ACCENT, backgroundColor: pressed ? `${ACCENT}25` : `${ACCENT}12`, alignItems: 'center' }]}
              >
                <Text style={{ fontSize: 13, fontFamily: 'Inter_600SemiBold', color: ACCENT }}>Risk 0.5%</Text>
              </Pressable>
              <Pressable
                onPress={() => applyRiskPreset(1)}
                style={({ pressed }) => [{ flex: 1, paddingVertical: 10, borderRadius: 8, borderWidth: 1, borderColor: ACCENT, backgroundColor: pressed ? `${ACCENT}25` : `${ACCENT}12`, alignItems: 'center' }]}
              >
                <Text style={{ fontSize: 13, fontFamily: 'Inter_600SemiBold', color: ACCENT }}>Risk 1%</Text>
              </Pressable>
            </View>
            <Text style={{ fontSize: 10, fontFamily: 'Inter_400Regular', color: colors.mutedForeground, marginTop: 8 }}>
              Otomatis ngitung Modal & Ukuran Posisi di bawah biar kerugian saat SL kena = persentase risk dari saldo. Standar umum: 0.5-1% per trade.
            </Text>
          </Section>
        )}

        {/* ── INPUT ─────────────────────────────────────────────────────── */}
        <Section title="INPUT">
          {/* Modal USDT */}
          <View style={[styles.inputRow, { borderColor: colors.border }]}>
            <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Modal</Text>
            <View style={styles.inputRight}>
              <TextInput
                style={[styles.inputField, { color: colors.foreground }]}
                keyboardType="decimal-pad"
                value={modalStr}
                onChangeText={handleModalChange}
                placeholder="100"
                placeholderTextColor={colors.mutedForeground}
                selectTextOnFocus
              />
              <Text style={[styles.inputUnit, { color: colors.mutedForeground }]}>USDT</Text>
            </View>
          </View>

          <View style={[styles.orDivider, { borderColor: colors.border }]}>
            <View style={[styles.orLine, { backgroundColor: colors.border }]} />
            <Text style={[styles.orText, { color: colors.mutedForeground }]}>atau</Text>
            <View style={[styles.orLine, { backgroundColor: colors.border }]} />
          </View>

          {/* Ukuran Posisi */}
          <View style={[styles.inputRow, { borderColor: colors.border }]}>
            <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Ukuran Posisi</Text>
            <View style={styles.inputRight}>
              <TextInput
                style={[styles.inputField, { color: colors.foreground }]}
                keyboardType="decimal-pad"
                value={contractsStr}
                onChangeText={handleContractsChange}
                placeholder="0.000000"
                placeholderTextColor={colors.mutedForeground}
                selectTextOnFocus
              />
              <Text style={[styles.inputUnit, { color: colors.mutedForeground }]}>{base}</Text>
            </View>
          </View>

          <Text style={[styles.inputHint, { color: colors.mutedForeground }]}>
            Isi salah satu — yang lain dihitung otomatis
          </Text>

          {/* Margin mode toggle */}
          <View style={styles.marginRow}>
            <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Mode Margin</Text>
            <View style={[styles.toggleGroup, { backgroundColor: colors.background, borderColor: colors.border }]}>
              {(['isolated', 'cross'] as const).map((mode) => (
                <Pressable
                  key={mode}
                  onPress={() => setMarginMode(mode)}
                  style={[
                    styles.toggleBtn,
                    marginMode === mode && { backgroundColor: ACCENT },
                  ]}
                >
                  <Text style={[
                    styles.toggleText,
                    { color: marginMode === mode ? colors.primaryForeground : colors.mutedForeground },
                  ]}>
                    {mode === 'isolated' ? 'Isolated' : 'Cross'}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        </Section>

        {/* ── HARGA (editable) ───────────────────────────────────────────── */}
        <Section title="HARGA">
          <View style={[styles.inputRow, { borderColor: colors.border }]}>
            <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Entry</Text>
            <View style={styles.inputRight}>
              <TextInput
                style={[styles.inputField, { color: colors.foreground }]}
                keyboardType="decimal-pad"
                value={entryStr}
                onChangeText={setEntryStr}
                placeholder="0"
                placeholderTextColor={colors.mutedForeground}
                selectTextOnFocus
              />
            </View>
          </View>
          <View style={[styles.inputRow, { borderColor: colors.border }]}>
            <Text style={[styles.inputLabel, { color: colors.bearish }]}>Stop Loss</Text>
            <View style={styles.inputRight}>
              <TextInput
                style={[styles.inputField, { color: colors.bearish }]}
                keyboardType="decimal-pad"
                value={slStr}
                onChangeText={setSlStr}
                placeholder="0"
                placeholderTextColor={colors.mutedForeground}
                selectTextOnFocus
              />
            </View>
          </View>
          <View style={[styles.inputRow, { borderColor: colors.border }]}>
            <Text style={[styles.inputLabel, { color: colors.bullish }]}>Take Profit 1</Text>
            <View style={styles.inputRight}>
              <TextInput
                style={[styles.inputField, { color: colors.bullish }]}
                keyboardType="decimal-pad"
                value={tp1Str}
                onChangeText={setTp1Str}
                placeholder="0"
                placeholderTextColor={colors.mutedForeground}
                selectTextOnFocus
              />
            </View>
          </View>
          <View style={[styles.inputRow, { borderColor: colors.border }]}>
            <Text style={[styles.inputLabel, { color: colors.gold }]}>Take Profit 2</Text>
            <View style={styles.inputRight}>
              <TextInput
                style={[styles.inputField, { color: colors.gold }]}
                keyboardType="decimal-pad"
                value={tp2Str}
                onChangeText={setTp2Str}
                placeholder="0"
                placeholderTextColor={colors.mutedForeground}
                selectTextOnFocus
              />
            </View>
          </View>
          <Text style={[styles.inputHint, { color: colors.mutedForeground }]}>
            Edit manual untuk simulasi skenario berbeda
          </Text>
        </Section>

        {/* ── HASIL ──────────────────────────────────────────────────────── */}
        <Section title="HASIL">
          {!hasPrices ? (
            <View style={styles.noPriceBox}>
              <Text style={[styles.noPriceText, { color: colors.mutedForeground }]}>
                Masukkan data harga terlebih dahulu
              </Text>
            </View>
          ) : !calc ? (
            <View style={styles.noPriceBox}>
              <Text style={[styles.noPriceText, { color: colors.mutedForeground }]}>
                Masukkan modal dan leverage untuk menghitung
              </Text>
            </View>
          ) : (
            <>
              {/* Position size & margin */}
              <View style={[styles.resultCard, { backgroundColor: colors.surfaceMid ?? colors.background, borderColor: colors.border }]}>
                <View style={styles.resultCardRow}>
                  <View style={styles.resultCardItem}>
                    <Text style={[styles.resultCardLabel, { color: colors.mutedForeground }]}>Ukuran Posisi</Text>
                    <Text style={[styles.resultCardValue, { color: colors.foreground }]}>
                      {calc.contracts.toFixed(6)}
                    </Text>
                    <Text style={[styles.resultCardUnit, { color: colors.mutedForeground }]}>{base}</Text>
                  </View>
                  <View style={[styles.resultCardDivider, { backgroundColor: colors.border }]} />
                  <View style={styles.resultCardItem}>
                    <Text style={[styles.resultCardLabel, { color: colors.mutedForeground }]}>Initial Margin</Text>
                    <Text style={[styles.resultCardValue, { color: colors.foreground }]}>
                      {calc.initialMargin.toFixed(2)}
                    </Text>
                    <Text style={[styles.resultCardUnit, { color: colors.mutedForeground }]}>USDT</Text>
                  </View>
                </View>
              </View>

              {/* Liquidation price */}
              <View style={[styles.liqBox, { borderColor: liqColor, backgroundColor: `${liqColor}12` }]}>
                <View style={styles.liqLeft}>
                  <Text style={[styles.liqLabel, { color: colors.mutedForeground }]}>
                    Liq. Price ({marginMode === 'cross' ? 'Cross' : 'Isolated'})
                  </Text>
                  <Text style={[styles.liqDist, { color: liqColor }]}>
                    Jarak {calc.liqDist.toFixed(1)}% dari entry
                    {calc.liqDist > 20 ? ' ✓ Aman' : calc.liqDist > 10 ? ' ⚠ Perhatikan' : ' ⚠ Berbahaya'}
                  </Text>
                </View>
                <Text style={[styles.liqPrice, { color: liqColor }]}>
                  {formatPrice(calc.liqPrice)}
                </Text>
              </View>

              {/* PnL rows */}
              <View style={[styles.pnlCard, { borderColor: colors.border }]}>
                {/* SL */}
                <View style={styles.pnlRow}>
                  <View style={styles.pnlLeft}>
                    <View style={[styles.pnlDot, { backgroundColor: colors.bearish }]} />
                    <Text style={[styles.pnlLabel, { color: colors.foreground }]}>STOP LOSS</Text>
                  </View>
                  <View style={styles.pnlRight}>
                    <Text style={[styles.pnlUsdt, { color: colors.bearish }]}>
                      {formatPnl(calc.pnlSL)} USDT
                    </Text>
                    <Text style={[styles.pnlRoe, { color: colors.bearish }]}>
                      ({calc.roeSL.toFixed(2)}%)
                    </Text>
                  </View>
                </View>

                <View style={[styles.divider, { backgroundColor: colors.border }]} />

                {/* TP1 */}
                <View style={styles.pnlRow}>
                  <View style={styles.pnlLeft}>
                    <View style={[styles.pnlDot, { backgroundColor: colors.bullish }]} />
                    <Text style={[styles.pnlLabel, { color: colors.foreground }]}>TAKE PROFIT 1</Text>
                  </View>
                  <View style={styles.pnlRight}>
                    <Text style={[styles.pnlUsdt, { color: colors.bullish }]}>
                      {formatPnl(calc.pnlTP1)} USDT
                    </Text>
                    <Text style={[styles.pnlRoe, { color: colors.bullish }]}>
                      ({calc.roeTP1.toFixed(2)}%)
                    </Text>
                  </View>
                </View>

                {takeProfit2 > 0 && (
                  <>
                    <View style={[styles.divider, { backgroundColor: colors.border }]} />
                    {/* TP2 */}
                    <View style={styles.pnlRow}>
                      <View style={styles.pnlLeft}>
                        <View style={[styles.pnlDot, { backgroundColor: colors.gold }]} />
                        <Text style={[styles.pnlLabel, { color: colors.foreground }]}>TAKE PROFIT 2</Text>
                      </View>
                      <View style={styles.pnlRight}>
                        <Text style={[styles.pnlUsdt, { color: colors.gold }]}>
                          {formatPnl(calc.pnlTP2)} USDT
                        </Text>
                        <Text style={[styles.pnlRoe, { color: colors.gold }]}>
                          ({calc.roeTP2.toFixed(2)}%)
                        </Text>
                      </View>
                    </View>
                  </>
                )}
              </View>
            </>
          )}
        </Section>

        {/* Disclaimer */}
        {/* ── TOMBOL BINANCE ──────────────────────────────────────────── */}
        {hasPrices && calc && (
          <View style={styles.binanceRow}>
            {/* Copy semua harga */}
            <Pressable
              onPress={async () => {
                const text = [
                  `Entry  : ${formatPrice(entryPrice)}`,
                  `SL     : ${formatPrice(stopLoss)}`,
                  `TP1    : ${formatPrice(takeProfit1)}`,
                  takeProfit2 > 0 ? `TP2    : ${formatPrice(takeProfit2)}` : '',
                  `Liq.   : ${formatPrice(calc.liqPrice)}`,
                  `Symbol : ${symbol}`,
                ].filter(Boolean).join('\n');
                await Clipboard.setStringAsync(text);
              }}
              style={({ pressed }) => [
                styles.binanceBtn,
                { backgroundColor: pressed ? `${colors.mutedForeground}20` : colors.card, borderColor: colors.border }
              ]}
            >
              <Text style={[styles.binanceBtnText, { color: colors.foreground }]}>📋 Copy Harga</Text>
            </Pressable>

            {/* Buka Binance */}
            <Pressable
              onPress={() => {
                const coin = symbol.replace('USDT', '');
                const url = `https://www.binance.com/id/futures/${coin}USDT`;
                Linking.openURL(url);
              }}
              style={({ pressed }) => [
                styles.binanceBtn,
                { backgroundColor: pressed ? '#F0B90B30' : '#F0B90B15', borderColor: '#F0B90B' }
              ]}
            >
              <Text style={[styles.binanceBtnText, { color: '#F0B90B' }]}>⚡ Buka Binance</Text>
            </Pressable>
          </View>
        )}

        <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
          * Kalkulasi menggunakan formula Binance Futures. Hanya untuk referensi. Bukan saran finansial.
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  headerTitle: { fontSize: 26, fontFamily: 'Inter_700Bold', letterSpacing: -0.5 },
  headerSub: { fontSize: 13, fontFamily: 'Inter_400Regular', marginTop: 2 },

  section: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 10,
    fontFamily: 'Inter_600SemiBold',
    letterSpacing: 1.5,
    marginBottom: 12,
  },

  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 7,
  },
  rowLabel: { fontSize: 13, fontFamily: 'Inter_400Regular' },
  rowValue: { fontSize: 13 },
  divider: { height: StyleSheet.hairlineWidth, marginVertical: 2 },

  // Inputs
  inputRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: StyleSheet.hairlineWidth,
    paddingVertical: 10,
  },
  inputLabel: { fontSize: 13, fontFamily: 'Inter_400Regular', flex: 1, marginRight: 8 },
  inputRight: { flexDirection: 'row', alignItems: 'center', gap: 6, flexShrink: 1 },
  inputField: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
    minWidth: 80,
    maxWidth: 160,
    flexShrink: 1,
    letterSpacing: -0.3,
  },
  inputUnit: { fontSize: 13, fontFamily: 'Inter_500Medium', minWidth: 40 },
  inputHint: { fontSize: 11, fontFamily: 'Inter_400Regular', marginTop: 6, textAlign: 'center' },

  orDivider: { flexDirection: 'row', alignItems: 'center', gap: 8, marginVertical: 4 },
  orLine: { flex: 1, height: StyleSheet.hairlineWidth },
  orText: { fontSize: 12, fontFamily: 'Inter_400Regular' },

  marginRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 12,
  },
  toggleGroup: {
    flexDirection: 'row',
    borderRadius: 8,
    borderWidth: 1,
    overflow: 'hidden',
  },
  toggleBtn: {
    paddingHorizontal: 14,
    paddingVertical: 7,
  },
  toggleText: { fontSize: 13, fontFamily: 'Inter_500Medium' },

  warningBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderRadius: 8,
    padding: 10,
    marginTop: 10,
  },
  warningText: { fontSize: 12, fontFamily: 'Inter_500Medium', flex: 1 },

  // No price state
  noPriceBox: { alignItems: 'center', gap: 8, paddingVertical: 12 },
  noPriceText: { fontSize: 13, fontFamily: 'Inter_400Regular', textAlign: 'center', lineHeight: 20 },

  // Results
  resultCard: {
    borderRadius: 10,
    borderWidth: 1,
    marginBottom: 12,
    overflow: 'hidden',
  },
  resultCardRow: { flexDirection: 'row' },
  resultCardItem: { flex: 1, alignItems: 'center', paddingVertical: 14 },
  resultCardDivider: { width: StyleSheet.hairlineWidth },
  resultCardLabel: { fontSize: 10, fontFamily: 'Inter_500Medium', letterSpacing: 0.5, marginBottom: 4 },
  resultCardValue: { fontSize: 20, fontFamily: 'Inter_700Bold', letterSpacing: -0.5 },
  resultCardUnit: { fontSize: 11, fontFamily: 'Inter_400Regular', marginTop: 2 },

  liqBox: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 10,
    padding: 14,
    marginBottom: 12,
  },
  liqLeft: { flex: 1 },
  liqLabel: { fontSize: 11, fontFamily: 'Inter_500Medium', letterSpacing: 0.5 },
  liqDist: { fontSize: 12, fontFamily: 'Inter_500Medium', marginTop: 2 },
  liqPrice: { fontSize: 20, fontFamily: 'Inter_700Bold', letterSpacing: -0.5 },

  pnlCard: {
    borderRadius: 10,
    borderWidth: 1,
    overflow: 'hidden',
  },
  pnlRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  pnlLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  pnlDot: { width: 8, height: 8, borderRadius: 4 },
  pnlLabel: { fontSize: 12, fontFamily: 'Inter_600SemiBold', letterSpacing: 0.3 },
  pnlRight: { alignItems: 'flex-end' },
  pnlUsdt: { fontSize: 16, fontFamily: 'Inter_700Bold', letterSpacing: -0.3 },
  pnlRoe: { fontSize: 12, fontFamily: 'Inter_500Medium', marginTop: 1 },

  disclaimer: { fontSize: 10, fontFamily: 'Inter_400Regular', textAlign: 'center', marginTop: 4, lineHeight: 16 },
  binanceRow: { flexDirection: 'row', gap: 10, marginBottom: 12 },
  binanceBtn: { flex: 1, borderWidth: 1, borderRadius: 10, paddingVertical: 12, alignItems: 'center' },
  binanceBtnText: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },

  // Long/Short toggle
  sideToggle: {
    flexDirection: 'row',
    borderRadius: 10,
    borderWidth: 1,
    overflow: 'hidden',
    height: 46,
    marginBottom: 12,
  },
  sideBtn: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  sideBtnText: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },

  // Leverage presets
  levRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  presets: { flexDirection: 'row', gap: 6, flexWrap: 'wrap' },
  presetBtn: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 6, borderWidth: 1 },
  presetText: { fontSize: 12, fontFamily: 'Inter_500Medium' },
});