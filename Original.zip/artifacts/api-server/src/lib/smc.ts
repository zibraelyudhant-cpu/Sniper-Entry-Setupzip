// SMC (Smart Money Concepts) Analysis Library
// Implements top-down analysis: H4 → H1 → 15M → 5M

const BINANCE_FUTURES_BASE = "https://fapi.binance.com";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface KlineData {
  opens: number[];
  highs: number[];
  lows: number[];
  closes: number[];
  volumes: number[];
  times: number[];
}

export interface PriceStructure {
  bias: "bullish" | "bearish" | "ranging";
  strength: "strong" | "moderate" | "weak" | "neutral";
  description: string;
}

export interface OrderBlock {
  high: number;
  low: number;
  mid: number;
  index: number;
  type: "bullish" | "bearish";
  strength: number;
  touches: number;       // berapa kali harga sudah masuk ke zona setelah terbentuk
  candlesAgo: number;    // berapa candle lalu zona ini terbentuk
}

export interface FVG {
  high: number;
  low: number;
  mid: number;
  index: number;
  type: "bullish" | "bearish";
  touches: number;       // berapa kali harga sudah masuk ke zona setelah terbentuk
  candlesAgo: number;    // berapa candle lalu zona ini terbentuk
}

export interface UnfilledOrderZone {
  high: number;
  low: number;
  mid: number;
  volume: number;
}

export interface SRLevel {
  price: number;
  touches: number;
  type: "support" | "resistance";
}

export interface SnDZone {
  high: number;
  low: number;
  mid: number;
  type: "supply" | "demand";
  strength: number;
}

export interface FibLevels {
  swingHigh: number;
  swingLow: number;
  levels: Record<string, number>;
}

export interface SelectedZone {
  high: number;
  low: number;
  mid: number;
  entryPrice: number;
  zoneType: string;
  tier: number;
  srLevel?: SRLevel;
  fibLevel?: number;
  touches?: number;
  candlesAgo?: number;
}

export interface RefinedZone {
  high: number;
  low: number;
  mid: number;
  entryPrice: number;
  zoneType: string;
  refined: boolean;
}

export interface EntryConfirmation {
  confirmed: boolean;
  candleType: string;
  entryPrice: number;
}

export interface SniperLevels {
  entryPrice: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  riskAmount: number;
  setupValidHours: number;
  estimatedHitHours: number;
  expiryHours: number;
}

export type DowPhase = 'accumulation' | 'participation' | 'distribution' | 'unknown';

export interface SkipConditions {
  shouldSkip: boolean;
  reasons: string[];
  rsi: number;
  rsiDivergence: boolean;
  chochDetected: boolean;
  chochH4Detected: boolean;
  oiChange: number;
  oiAccumulation: boolean;
  oiAccumulationDesc: string;
  fundingRate: number;
  dowPhase: DowPhase;
  dowPhaseDesc: string;
  volumeTrendValid: boolean;
  volumeTrendDesc: string;
}

export interface SniperResult {
  status: "ready" | "no_trend" | "no_zone" | "skip_conditions" | "error";
  message: string;
  symbol: string;
  currentPrice: number;
  timestamp: string;
  bias?: "bullish" | "bearish";
  entryPrice?: number;
  stopLoss?: number;
  takeProfit1?: number;
  takeProfit2?: number;
  h4?: { bias: string; strength: string };
  zoneType?: string;
  zoneRange?: { low: number; high: number };
  refinedZoneType?: string;
  entryConfirmed?: boolean;
  confirmationCandle?: string;
  rsi?: number;
  rsiDivergence?: boolean;
  chochDetected?: boolean;
  oiChange?: number;
  oiAccumulation?: boolean;
  oiAccumulationDesc?: string;
  fundingRate?: number;
  setupValidHours?: number;
  estimatedHitHours?: number;
  expiryHours?: number;
  skipReasons?: string[];
  reasoning?: string;
  // Confirmation fields
  rejection15M?: boolean;
  rejection15MCandle?: string;
  choch15M?: boolean;
  choch15MDescription?: string;
  patternConfirmed?: boolean;
  patternName?: string;
  // Probability scoring
  profitProbability?: number;
  probabilityFactors?: string[];
  // Teori Dow
  dowPhase?: string;
  dowPhaseDesc?: string;
  volumeTrendValid?: boolean;
  volumeTrendDesc?: string;
  chochH4Detected?: boolean;
  // Multi-TF Confluence
  h4ConfluenceConfirmed?: boolean;
  h4ConfluenceStrength?: string;
  h4ConfluenceDesc?: string;
}

// ─── Data Fetching ────────────────────────────────────────────────────────────

// Cache klines untuk kurangi request ke Binance
const klinesCache = new Map<string, { data: KlineData; ts: number }>();
const KLINES_CACHE_MS = 5 * 60 * 1000; // 5 menit

export async function fetchKlines(
  symbol: string,
  interval: string,
  limit: number
): Promise<KlineData> {
  const cacheKey = `${symbol}_${interval}_${limit}`;
  const cached = klinesCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < KLINES_CACHE_MS) return cached.data;

  const url = `${BINANCE_FUTURES_BASE}/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;

  // Retry max 2x dengan delay kalau kena rate limit (418/429)
  for (let attempt = 0; attempt < 2; attempt++) {
    const res = await fetch(url, {
      headers: { 'Accept': 'application/json' }
    });
    if (res.status === 418 || res.status === 429) {
      // Rate limited — tunggu sebentar lalu retry
      await new Promise(r => setTimeout(r, 3000 * (attempt + 1)));
      continue;
    }
    if (!res.ok) throw new Error(`Klines fetch failed: ${res.status}`);
    const data: unknown[][] = await res.json();
    const result: KlineData = {
      opens: data.map((k) => parseFloat(k[1] as string)),
      highs: data.map((k) => parseFloat(k[2] as string)),
      lows: data.map((k) => parseFloat(k[3] as string)),
      closes: data.map((k) => parseFloat(k[4] as string)),
      volumes: data.map((k) => parseFloat(k[5] as string)),
      times: data.map((k) => k[0] as number),
    };
    klinesCache.set(cacheKey, { data: result, ts: Date.now() });
    return result;
  }
  throw new Error(`Klines fetch failed after retries: rate limited`);
}

// ─── Utility Calculations ─────────────────────────────────────────────────────

export function calcMACD(
  closes: number[],
  fast = 12,
  slow = 26,
  signal = 9
): { macdLine: number; signalLine: number; histogram: number } {
  const ema = (data: number[], period: number): number[] => {
    const k = 2 / (period + 1);
    let e = data.slice(0, period).reduce((a, b) => a + b, 0) / period;
    const result = [e];
    for (let i = period; i < data.length; i++) {
      e = data[i] * k + e * (1 - k);
      result.push(e);
    }
    return result;
  };
  if (closes.length < slow + signal) {
    return { macdLine: 0, signalLine: 0, histogram: 0 };
  }
  const ef = ema(closes, fast);
  const es = ema(closes, slow);
  const diff = ef.length - es.length;
  const macdSeries = ef.slice(diff).map((v, i) => v - es[i]);
  const signalSeries = ema(macdSeries, signal);
  const ml = macdSeries[macdSeries.length - 1];
  const sl = signalSeries[signalSeries.length - 1];
  return { macdLine: ml, signalLine: sl, histogram: ml - sl };
}

export function calcADX(
  highs: number[],
  lows: number[],
  closes: number[],
  period = 14
): number {
  const n = closes.length;
  if (n < period * 2) return 0;
  const trs: number[] = [];
  const plusDMs: number[] = [];
  const minusDMs: number[] = [];
  for (let i = 1; i < n; i++) {
    const hl = highs[i] - lows[i];
    const hc = Math.abs(highs[i] - closes[i - 1]);
    const lc = Math.abs(lows[i] - closes[i - 1]);
    trs.push(Math.max(hl, hc, lc));
    const upMove = highs[i] - highs[i - 1];
    const downMove = lows[i - 1] - lows[i];
    plusDMs.push(upMove > downMove && upMove > 0 ? upMove : 0);
    minusDMs.push(downMove > upMove && downMove > 0 ? downMove : 0);
  }
  const smooth = (arr: number[]): number[] => {
    let val = arr.slice(0, period).reduce((a, b) => a + b, 0);
    const result = [val];
    for (let i = period; i < arr.length; i++) {
      val = val - val / period + arr[i];
      result.push(val);
    }
    return result;
  };
  const atr14 = smooth(trs);
  const plusDI = smooth(plusDMs).map((v, i) => (v / atr14[i]) * 100);
  const minusDI = smooth(minusDMs).map((v, i) => (v / atr14[i]) * 100);
  const dx = plusDI.map((p, i) => {
    const sum = p + minusDI[i];
    return sum === 0 ? 0 : (Math.abs(p - minusDI[i]) / sum) * 100;
  });
  const adxSeries = smooth(dx);
  return adxSeries[adxSeries.length - 1] ?? 0;
}
function calcATR(
  highs: number[],
  lows: number[],
  closes: number[],
  period = 14
): number {
  const trs: number[] = [];
  for (let i = 1; i < highs.length; i++) {
    const hl = highs[i] - lows[i];
    const hc = Math.abs(highs[i] - closes[i - 1]);
    const lc = Math.abs(lows[i] - closes[i - 1]);
    trs.push(Math.max(hl, hc, lc));
  }
  const slice = trs.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / slice.length;
}

function calcRSI(closes: number[], period = 14): number {
  if (closes.length < period + 1) return 50;
  const gains: number[] = [];
  const losses: number[] = [];
  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    gains.push(diff > 0 ? diff : 0);
    losses.push(diff < 0 ? -diff : 0);
  }
  let avgGain = gains.reduce((a, b) => a + b, 0) / period;
  let avgLoss = losses.reduce((a, b) => a + b, 0) / period;
  const recentCloses = closes.slice(period);
  const prevCloses = closes.slice(period - 1, -1);
  for (let i = 0; i < recentCloses.length; i++) {
    const diff = recentCloses[i] - prevCloses[i];
    const gain = diff > 0 ? diff : 0;
    const loss = diff < 0 ? -diff : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
  }
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

function findSwingHighs(highs: number[], lookback: number): number[] {
  const swings: number[] = [];
  for (let i = 2; i < highs.length - 2; i++) {
    if (
      highs[i] > highs[i - 1] &&
      highs[i] > highs[i - 2] &&
      highs[i] > highs[i + 1] &&
      highs[i] > highs[i + 2]
    ) {
      swings.push(highs[i]);
    }
  }
  return swings.slice(-lookback);
}

function findSwingLows(lows: number[], lookback: number): number[] {
  const swings: number[] = [];
  for (let i = 2; i < lows.length - 2; i++) {
    if (
      lows[i] < lows[i - 1] &&
      lows[i] < lows[i - 2] &&
      lows[i] < lows[i + 1] &&
      lows[i] < lows[i + 2]
    ) {
      swings.push(lows[i]);
    }
  }
  return swings.slice(-lookback);
}

// ─── Step 1: Price Action Structure ──────────────────────────────────────────

export function analyzePriceActionStructure(
  highs: number[],
  lows: number[],
  closes: number[]
): PriceStructure {
  // Pakai lookback lebih besar (8) untuk stabilitas sinyal
  const swingHighs = findSwingHighs(highs, 8);
  const swingLows = findSwingLows(lows, 8);

  if (swingHighs.length < 3 || swingLows.length < 3) {
    return { bias: "ranging", strength: "neutral", description: "Insufficient swing data" };
  }

  // Cek 4 swing terakhir (bukan 3) untuk konsistensi lebih kuat
  const lastHighs = swingHighs.slice(-4);
  const lastLows = swingLows.slice(-4);

  let bullishSignals = 0;
  let bearishSignals = 0;

  // Higher Highs
  for (let i = 1; i < lastHighs.length; i++) {
    if (lastHighs[i] > lastHighs[i - 1]) bullishSignals++;
    else if (lastHighs[i] < lastHighs[i - 1]) bearishSignals++;
  }

  // Higher Lows
  for (let i = 1; i < lastLows.length; i++) {
    if (lastLows[i] > lastLows[i - 1]) bullishSignals++;
    else if (lastLows[i] < lastLows[i - 1]) bearishSignals++;
  }

  // Momentum: bandingkan rata-rata 10 close terakhir vs 20 close terakhir
  // Lebih stabil dari slice candle tunggal
  const recent20 = closes.slice(-20);
  const avg10 = recent20.slice(-10).reduce((a, b) => a + b, 0) / 10;
  const avg20 = recent20.reduce((a, b) => a + b, 0) / 20;
  if (avg10 > avg20 * 1.001) bullishSignals++;
  else if (avg10 < avg20 * 0.999) bearishSignals++;

  const total = bullishSignals + bearishSignals;
  if (total === 0) return { bias: "ranging", strength: "neutral", description: "No clear structure" };

  const dominance = Math.max(bullishSignals, bearishSignals) / total;

  // strong >= 0.7 (5/7 sinyal), moderate >= 0.55 (4/7), weak = sisanya
  if (bullishSignals > bearishSignals) {
    const strength = dominance >= 0.7 ? "strong" : dominance >= 0.55 ? "moderate" : "weak";
    return { bias: "bullish", strength, description: `HH+HL (${bullishSignals}/${total} sinyal bullish)` };
  } else if (bearishSignals > bullishSignals) {
    const strength = dominance >= 0.7 ? "strong" : dominance >= 0.55 ? "moderate" : "weak";
    return { bias: "bearish", strength, description: `LH+LL (${bearishSignals}/${total} sinyal bearish)` };
  }

  return { bias: "ranging", strength: "neutral", description: "Struktur ranging/sideways" };
}

// ─── Step 2: Detect Zones at H1 ──────────────────────────────────────────────

export function detectOrderBlocksH1(
  opens: number[],
  highs: number[],
  lows: number[],
  closes: number[],
  bias: "bullish" | "bearish",
  lookback = 50
): OrderBlock[] {
  const obs: OrderBlock[] = [];
  const start = Math.max(0, opens.length - lookback);

  for (let i = start; i < opens.length - 3; i++) {
    if (bias === "bullish") {
      // Bearish OB: bearish candle followed by strong bullish impulse
      const isBearishCandle = closes[i] < opens[i];
      if (!isBearishCandle) continue;

      // Check for strong bullish move after
      let maxClose = closes[i];
      for (let j = i + 1; j < Math.min(i + 5, closes.length); j++) {
        maxClose = Math.max(maxClose, closes[j]);
      }

      const range = highs[i] - lows[i];
      const impulse = maxClose - closes[i];
      if (impulse > range * 1.5) {
        const strength = impulse / range;
        // Hitung touches: berapa kali harga masuk ke zona setelah OB terbentuk
        let touches = 0;
        for (let j = i + 1; j < closes.length; j++) {
          if (lows[j] <= highs[i] && highs[j] >= lows[i]) touches++;
        }
        obs.push({
          high: highs[i],
          low: lows[i],
          mid: (highs[i] + lows[i]) / 2,
          index: i,
          type: "bullish",
          strength,
          touches,
          candlesAgo: opens.length - 1 - i,
        });
      }
    } else {
      // Bullish OB: bullish candle followed by strong bearish impulse
      const isBullishCandle = closes[i] > opens[i];
      if (!isBullishCandle) continue;

      let minClose = closes[i];
      for (let j = i + 1; j < Math.min(i + 5, closes.length); j++) {
        minClose = Math.min(minClose, closes[j]);
      }

      const range = highs[i] - lows[i];
      const impulse = closes[i] - minClose;
      if (impulse > range * 1.5) {
        const strength = impulse / range;
        let touches = 0;
        for (let j = i + 1; j < closes.length; j++) {
          if (lows[j] <= highs[i] && highs[j] >= lows[i]) touches++;
        }
        obs.push({
          high: highs[i],
          low: lows[i],
          mid: (highs[i] + lows[i]) / 2,
          index: i,
          type: "bearish",
          strength,
          touches,
          candlesAgo: opens.length - 1 - i,
        });
      }
    }
  }

  // Filter: zona fresh (touches <= 1) diprioritaskan, tapi tetap include touches 2 kalau tidak ada yang fresh
  const fresh = obs.filter(ob => ob.touches <= 1);
  const pool = fresh.length > 0 ? fresh : obs.filter(ob => ob.touches <= 2);
  const final = pool.length > 0 ? pool : obs;

  // Sort by strength and recency, return top 5
  return final
    .sort((a, b) => b.strength * (b.index / opens.length) - a.strength * (a.index / opens.length))
    .slice(0, 5);
}

export function detectFVGH1(
  highs: number[],
  lows: number[],
  bias: "bullish" | "bearish",
  lookback = 50
): FVG[] {
  const fvgs: FVG[] = [];
  const start = Math.max(1, highs.length - lookback);

  for (let i = start; i < highs.length - 1; i++) {
    if (bias === "bullish") {
      // Bullish FVG: gap up — candle[i-1].high < candle[i+1].low
      if (highs[i - 1] < lows[i + 1]) {
        const low = highs[i - 1];
        const high = lows[i + 1];
        // Hitung touches: berapa kali harga masuk ke FVG setelah terbentuk
        let touches = 0;
        for (let j = i + 2; j < highs.length; j++) {
          if (lows[j] <= high && highs[j] >= low) touches++;
        }
        fvgs.push({ high, low, mid: (high + low) / 2, index: i, type: "bullish", touches, candlesAgo: highs.length - 1 - i });
      }
    } else {
      // Bearish FVG: gap down — candle[i-1].low > candle[i+1].high
      if (lows[i - 1] > highs[i + 1]) {
        const high = lows[i - 1];
        const low = highs[i + 1];
        let touches = 0;
        for (let j = i + 2; j < highs.length; j++) {
          if (lows[j] <= high && highs[j] >= low) touches++;
        }
        fvgs.push({ high, low, mid: (high + low) / 2, index: i, type: "bearish", touches, candlesAgo: highs.length - 1 - i });
      }
    }
  }

  // Filter: prioritaskan FVG fresh (touches = 0, belum pernah disentuh)
  const fresh = fvgs.filter(f => f.touches === 0);
  const pool = fresh.length > 0 ? fresh : fvgs.filter(f => f.touches <= 1);
  const final = pool.length > 0 ? pool : fvgs;

  return final.slice(-5);
}

export async function detectUnfilledOrdersH1(
  symbol: string,
  currentPrice: number,
  bias: "bullish" | "bearish"
): Promise<UnfilledOrderZone[]> {
  try {
    const url = `${BINANCE_FUTURES_BASE}/fapi/v1/aggTrades?symbol=${symbol}&limit=1000`;
    const res = await fetch(url);
    if (!res.ok) return [];
    const trades: Array<{ p: string; q: string }> = await res.json();

    // Bin trades by price level (0.05% bins)
    const binSize = currentPrice * 0.0005;
    const bins = new Map<number, number>();
    for (const t of trades) {
      const price = parseFloat(t.p);
      const qty = parseFloat(t.q);
      const bin = Math.floor(price / binSize) * binSize;
      bins.set(bin, (bins.get(bin) ?? 0) + qty);
    }

    // Find low-volume zones (potential unfilled orders)
    const entries = Array.from(bins.entries()).sort((a, b) => a[0] - b[0]);
    const avgVol = entries.reduce((s, e) => s + e[1], 0) / entries.length;
    const zones: UnfilledOrderZone[] = [];

    for (const [price, vol] of entries) {
      if (vol < avgVol * 0.3) {
        // Low volume = potential unfilled order area
        if (bias === "bullish" && price < currentPrice) {
          zones.push({ high: price + binSize, low: price, mid: price + binSize / 2, volume: vol });
        } else if (bias === "bearish" && price > currentPrice) {
          zones.push({ high: price + binSize, low: price, mid: price + binSize / 2, volume: vol });
        }
      }
    }

    return zones.slice(0, 3);
  } catch {
    return [];
  }
}

export function detectSRLevels(
  highs: number[],
  lows: number[],
  closes: number[],
  lookback = 100
): SRLevel[] {
  const recentHighs = highs.slice(-lookback);
  const recentLows = lows.slice(-lookback);
  const threshold = (Math.max(...recentHighs) - Math.min(...recentLows)) * 0.005;

  const levels: Array<{ price: number; touches: number; type: "support" | "resistance" }> = [];

  // Collect swing highs as resistance
  for (let i = 2; i < recentHighs.length - 2; i++) {
    if (
      recentHighs[i] > recentHighs[i - 1] &&
      recentHighs[i] > recentHighs[i - 2] &&
      recentHighs[i] > recentHighs[i + 1] &&
      recentHighs[i] > recentHighs[i + 2]
    ) {
      let merged = false;
      for (const lvl of levels) {
        if (Math.abs(lvl.price - recentHighs[i]) < threshold) {
          lvl.touches++;
          merged = true;
          break;
        }
      }
      if (!merged) levels.push({ price: recentHighs[i], touches: 1, type: "resistance" });
    }
  }

  // Collect swing lows as support
  for (let i = 2; i < recentLows.length - 2; i++) {
    if (
      recentLows[i] < recentLows[i - 1] &&
      recentLows[i] < recentLows[i - 2] &&
      recentLows[i] < recentLows[i + 1] &&
      recentLows[i] < recentLows[i + 2]
    ) {
      let merged = false;
      for (const lvl of levels) {
        if (Math.abs(lvl.price - recentLows[i]) < threshold) {
          lvl.touches++;
          merged = true;
          break;
        }
      }
      if (!merged) levels.push({ price: recentLows[i], touches: 1, type: "support" });
    }
  }

  return levels.filter((l) => l.touches >= 2).sort((a, b) => b.touches - a.touches).slice(0, 8);
}

export function detectSnDZones(
  opens: number[],
  highs: number[],
  lows: number[],
  closes: number[]
): SnDZone[] {
  const zones: SnDZone[] = [];
  const lookback = Math.min(100, opens.length);

  for (let i = 2; i < lookback - 2; i++) {
    const candleSize = Math.abs(closes[i] - opens[i]);
    const avgSize =
      (Math.abs(closes[i - 1] - opens[i - 1]) +
        Math.abs(closes[i - 2] - opens[i - 2])) /
      2;

    // Strong bullish candle after consolidation → demand zone (support area)
    if (
      closes[i] > opens[i] &&
      candleSize > avgSize * 2 &&
      closes[i] > highs[i - 1]
    ) {
      zones.push({
        high: highs[i],
        low: lows[i],
        mid: (highs[i] + lows[i]) / 2,
        type: "demand",
        strength: candleSize / avgSize,
      });
    }

    // Strong bearish candle after consolidation → supply zone (resistance area)
    if (
      closes[i] < opens[i] &&
      candleSize > avgSize * 2 &&
      closes[i] < lows[i - 1]
    ) {
      zones.push({
        high: highs[i],
        low: lows[i],
        mid: (highs[i] + lows[i]) / 2,
        type: "supply",
        strength: candleSize / avgSize,
      });
    }
  }

  return zones.sort((a, b) => b.strength - a.strength).slice(0, 5);
}

export function calcFibonacci(
  highs: number[],
  lows: number[],
  closes: number[]
): FibLevels | null {
  const recentHighs = highs.slice(-30);
  const recentLows = lows.slice(-30);
  const swingHigh = Math.max(...recentHighs);
  const swingLow = Math.min(...recentLows);
  const range = swingHigh - swingLow;

  if (range === 0) return null;

  return {
    swingHigh,
    swingLow,
    levels: {
      "0.0": swingLow,
      "0.236": swingLow + range * 0.236,
      "0.382": swingLow + range * 0.382,
      "0.5": swingLow + range * 0.5,
      "0.618": swingLow + range * 0.618,
      "0.786": swingLow + range * 0.786,
      "1.0": swingHigh,
    },
  };
}

// ─── Zone Selection (Hierarchy) ───────────────────────────────────────────────

export function selectBestZoneH1(
  obs: OrderBlock[],
  fvgs: FVG[],
  unfilledOrders: UnfilledOrderZone[],
  srLevels: SRLevel[],
  sndZones: SnDZone[],
  fibLevels: FibLevels | null,
  bias: "bullish" | "bearish",
  currentPrice: number
): SelectedZone | null {
  // Filter zones relevant to bias direction (below price for BUY, above for SELL)
  const priceFilter = (low: number, high: number) =>
    bias === "bullish"
      ? low < currentPrice && high < currentPrice * 1.1
      : high > currentPrice && low > currentPrice * 0.9;

  // Helper: does zone overlap with another?
  const overlaps = (
    zLow: number,
    zHigh: number,
    other: { low: number; high: number }
  ) => zLow <= other.high && zHigh >= other.low;

  // TIER 1: Unfilled Order within OB
  for (const uo of unfilledOrders) {
    if (!priceFilter(uo.low, uo.high)) continue;
    for (const ob of obs) {
      if (overlaps(uo.low, uo.high, ob)) {
        return {
          high: ob.high,
          low: ob.low,
          mid: uo.mid,
          entryPrice: uo.mid,
          zoneType: "Unfilled Order dalam OB",
          tier: 1,
          touches: ob.touches,
          candlesAgo: ob.candlesAgo,
        };
      }
    }
  }

  // TIER 2: OB + FVG overlap
  for (const ob of obs) {
    if (!priceFilter(ob.low, ob.high)) continue;
    for (const fvg of fvgs) {
      if (overlaps(ob.low, ob.high, fvg)) {
        return {
          high: ob.high,
          low: ob.low,
          mid: fvg.mid,
          entryPrice: fvg.mid,
          zoneType: "Order Block + FVG overlap",
          tier: 2,
          touches: Math.max(ob.touches, fvg.touches),
          candlesAgo: ob.candlesAgo,
        };
      }
    }
  }

  // TIER 3: OB + S&R or SnD confluence
  for (const ob of obs) {
    if (!priceFilter(ob.low, ob.high)) continue;
    const threshold = (ob.high - ob.low) * 2;
    for (const sr of srLevels) {
      if (Math.abs(sr.price - ob.mid) < threshold) {
        const goldenZone =
          bias === "bullish"
            ? ob.low + (ob.high - ob.low) * 0.382
            : ob.high - (ob.high - ob.low) * 0.382;
        return {
          high: ob.high,
          low: ob.low,
          mid: goldenZone,
          entryPrice: goldenZone,
          zoneType: "Order Block + S&R confluence",
          tier: 3,
          srLevel: sr,
          touches: ob.touches,
          candlesAgo: ob.candlesAgo,
        };
      }
    }
    for (const snd of sndZones) {
      if (overlaps(ob.low, ob.high, snd)) {
        const goldenZone =
          bias === "bullish"
            ? ob.low + (ob.high - ob.low) * 0.382
            : ob.high - (ob.high - ob.low) * 0.382;
        return {
          high: ob.high,
          low: ob.low,
          mid: goldenZone,
          entryPrice: goldenZone,
          zoneType: "Order Block + Supply/Demand confluence",
          tier: 3,
          touches: ob.touches,
          candlesAgo: ob.candlesAgo,
        };
      }
    }
  }

  // TIER 4: OB murni
  if (obs.length > 0) {
    const ob = obs[0];
    if (priceFilter(ob.low, ob.high)) {
      const goldenZone =
        bias === "bullish"
          ? ob.low + (ob.high - ob.low) * 0.382
          : ob.high - (ob.high - ob.low) * 0.382;
      return {
        high: ob.high,
        low: ob.low,
        mid: goldenZone,
        entryPrice: goldenZone,
        zoneType: "Order Block murni",
        tier: 4,
        touches: ob.touches,
        candlesAgo: ob.candlesAgo,
      };
    }
  }

  // TIER 5: FVG + S&R or SnD
  for (const fvg of fvgs) {
    if (!priceFilter(fvg.low, fvg.high)) continue;
    const threshold = (fvg.high - fvg.low) * 3;
    for (const sr of srLevels) {
      if (Math.abs(sr.price - fvg.mid) < threshold) {
        return {
          high: fvg.high,
          low: fvg.low,
          mid: fvg.mid,
          entryPrice: fvg.mid,
          zoneType: "FVG + S&R confluence",
          tier: 5,
          srLevel: sr,
          touches: fvg.touches,
          candlesAgo: fvg.candlesAgo,
        };
      }
    }
  }

  // TIER 6: FVG murni
  const validFvgs = fvgs.filter((f) => priceFilter(f.low, f.high));
  if (validFvgs.length > 0) {
    const fvg = validFvgs[validFvgs.length - 1];
    return {
      high: fvg.high,
      low: fvg.low,
      mid: fvg.mid,
      entryPrice: fvg.mid,
      zoneType: "FVG murni",
      tier: 6,
      touches: fvg.touches,
      candlesAgo: fvg.candlesAgo,
    };
  }

  // TIER 7: S&R/SnD + Fibonacci (WAJIB ada Fib, kalau tidak skip)
  if (fibLevels) {
    const fibPrices = [
      fibLevels.levels["0.382"],
      fibLevels.levels["0.5"],
      fibLevels.levels["0.618"],
      fibLevels.levels["0.786"],
    ];
    for (const sr of srLevels) {
      for (const fibPrice of fibPrices) {
        if (
          Math.abs(sr.price - fibPrice) / currentPrice < 0.003 &&
          priceFilter(fibPrice * 0.998, fibPrice * 1.002)
        ) {
          return {
            high: fibPrice * 1.002,
            low: fibPrice * 0.998,
            mid: fibPrice,
            entryPrice: fibPrice,
            zoneType: "S&R + Fibonacci",
            tier: 7,
            srLevel: sr,
            fibLevel: fibPrice,
          };
        }
      }
    }
  }

  return null;
}

// ─── Step 3: Refine at 15M ────────────────────────────────────────────────────

export function refineZone15M(
  zone: SelectedZone,
  opens15m: number[],
  highs15m: number[],
  lows15m: number[],
  closes15m: number[],
  bias: "bullish" | "bearish"
): RefinedZone {
  // Look for OB or FVG within the H1 zone
  const obs15m = detectOrderBlocksH1(opens15m, highs15m, lows15m, closes15m, bias, 30);
  const fvgs15m = detectFVGH1(highs15m, lows15m, bias, 30);

  // Find OB within zone
  for (const ob of obs15m) {
    if (ob.low >= zone.low && ob.high <= zone.high) {
      const goldenZone =
        bias === "bullish"
          ? ob.low + (ob.high - ob.low) * 0.382
          : ob.high - (ob.high - ob.low) * 0.382;
      return {
        high: ob.high,
        low: ob.low,
        mid: goldenZone,
        entryPrice: goldenZone,
        zoneType: `OB 15M dalam range H1 (${zone.zoneType})`,
        refined: true,
      };
    }
  }

  // Find FVG within zone
  for (const fvg of fvgs15m) {
    if (fvg.low >= zone.low && fvg.high <= zone.high) {
      return {
        high: fvg.high,
        low: fvg.low,
        mid: fvg.mid,
        entryPrice: fvg.mid,
        zoneType: `FVG 15M dalam range H1 (${zone.zoneType})`,
        refined: true,
      };
    }
  }

  // Use H1 zone directly
  return {
    high: zone.high,
    low: zone.low,
    mid: zone.mid,
    entryPrice: zone.entryPrice,
    zoneType: zone.zoneType,
    refined: false,
  };
}


// ─── Multi-TF Zone Refinement: H1 → 15M → 5M ────────────────────────────────
// Cari zona terkuat di setiap TF dalam batas zona TF lebih tinggi
// Hierarki zona per TF: OB > FVG > S&R > Fib > UFO

function findBestZoneInRange(
  opens: number[], highs: number[], lows: number[], closes: number[], volumes: number[],
  bias: "bullish" | "bearish",
  zoneLow: number, zoneHigh: number,
  tfLabel: string,
  parentZoneType: string,
  currentPrice: number
): RefinedZone | null {
  const range = zoneHigh - zoneLow;
  if (range <= 0) return null;
  const margin = range * 0.15; // toleransi 15% keluar zona parent

  // 1. OB dalam zona
  const obs = detectOrderBlocksH1(opens, highs, lows, closes, bias, 50);
  for (const ob of obs) {
    const inZone = bias === "bullish"
      ? ob.high <= zoneHigh + margin && ob.low >= zoneLow - margin && ob.high < currentPrice
      : ob.low >= zoneLow - margin && ob.high <= zoneHigh + margin && ob.low > currentPrice;
    if (inZone) {
      const entry = bias === "bullish"
        ? ob.low + (ob.high - ob.low) * 0.382
        : ob.high - (ob.high - ob.low) * 0.382;
      return { high: ob.high, low: ob.low, mid: (ob.high + ob.low) / 2, entryPrice: entry, zoneType: `OB ${tfLabel} (${parentZoneType})`, refined: true };
    }
  }

  // 2. FVG dalam zona
  const fvgs = detectFVGH1(highs, lows, bias, 50);
  for (const fvg of fvgs) {
    const inZone = fvg.low >= zoneLow - margin && fvg.high <= zoneHigh + margin;
    if (inZone) {
      const inPriceRange = bias === "bullish" ? fvg.high < currentPrice : fvg.low > currentPrice;
      if (inPriceRange) return { high: fvg.high, low: fvg.low, mid: fvg.mid, entryPrice: fvg.mid, zoneType: `FVG ${tfLabel} (${parentZoneType})`, refined: true };
    }
  }

  // 3. S&R dalam zona
  const srLevels = detectSRLevels(highs, lows, closes);
  for (const sr of srLevels) {
    const inZone = sr.price >= zoneLow - margin && sr.price <= zoneHigh + margin;
    if (inZone) {
      const isRelevant = bias === "bullish" ? sr.price < currentPrice : sr.price > currentPrice;
      if (isRelevant) {
        const hw = range * 0.1;
        return { high: sr.price + hw, low: sr.price - hw, mid: sr.price, entryPrice: sr.price, zoneType: `S&R ${tfLabel} ${sr.type} (${parentZoneType})`, refined: true };
      }
    }
  }

  // 4. Fibonacci dalam zona
  const fib = calcFibonacci(highs, lows, closes);
  if (fib) {
    const fibKeys = bias === "bullish" ? ["0.618", "0.5", "0.382"] : ["0.382", "0.5", "0.618"];
    for (const k of fibKeys) {
      const lvl = fib.levels[k as keyof typeof fib.levels];
      if (lvl && lvl >= zoneLow - margin && lvl <= zoneHigh + margin) {
        const inPriceRange = bias === "bullish" ? lvl < currentPrice : lvl > currentPrice;
        if (inPriceRange) {
          const hw = range * 0.08;
          return { high: lvl + hw, low: lvl - hw, mid: lvl, entryPrice: lvl, zoneType: `Fib ${k} ${tfLabel} (${parentZoneType})`, refined: true };
        }
      }
    }
  }

  // 5. UFO — cari volume void dalam zona (low volume area = unfilled)
  const avgVol = volumes.length > 0 ? volumes.slice(-50).reduce((a, b) => a + b, 0) / Math.min(50, volumes.length) : 0;
  if (avgVol > 0) {
    for (let i = Math.max(0, highs.length - 50); i < highs.length - 3; i++) {
      const candleHigh = highs[i], candleLow = lows[i];
      const vol = volumes[i] ?? 0;
      const inZone = candleLow >= zoneLow - margin && candleHigh <= zoneHigh + margin;
      const isLowVol = vol < avgVol * 0.4; // volume < 40% avg = area tidak terisi
      const isGap = highs[i + 1] > candleHigh * 1.001 || lows[i + 1] < candleLow * 0.999; // ada gap setelahnya
      if (inZone && isLowVol && isGap) {
        const inPriceRange = bias === "bullish" ? candleHigh < currentPrice : candleLow > currentPrice;
        if (inPriceRange) return { high: candleHigh, low: candleLow, mid: (candleHigh + candleLow) / 2, entryPrice: (candleHigh + candleLow) / 2, zoneType: `UFO ${tfLabel} (${parentZoneType})`, refined: true };
      }
    }
  }

  return null;
}

export function refineZoneMultiTF(
  h1Zone: SelectedZone,
  opens15m: number[], highs15m: number[], lows15m: number[], closes15m: number[], volumes15m: number[],
  opens5m: number[], highs5m: number[], lows5m: number[], closes5m: number[], volumes5m: number[],
  bias: "bullish" | "bearish",
  currentPrice: number
): RefinedZone {
  // Step 1: Cari zona terkuat di 15M dalam range H1
  const zone15M = findBestZoneInRange(
    opens15m, highs15m, lows15m, closes15m, volumes15m,
    bias, h1Zone.low, h1Zone.high, "15M", h1Zone.zoneType, currentPrice
  );

  if (zone15M) {
    // Step 2: Cari zona terkuat di 5M dalam range zona 15M yang ditemukan
    const zone5M = findBestZoneInRange(
      opens5m, highs5m, lows5m, closes5m, volumes5m,
      bias, zone15M.low, zone15M.high, "5M", zone15M.zoneType, currentPrice
    );
    if (zone5M) return zone5M; // Zona 5M paling presisi
    return zone15M; // Fallback ke 15M
  }

  // Fallback ke H1 zone langsung
  return {
    high: h1Zone.high, low: h1Zone.low, mid: h1Zone.mid,
    entryPrice: h1Zone.entryPrice, zoneType: h1Zone.zoneType, refined: false,
  };
}

// ─── Step 4: Entry Confirmation at 5M ────────────────────────────────────────

export interface Rejection15M {
  confirmed: boolean;
  candleType: string;
  rejectionHigh: number;  // high candle rejection (untuk SL bearish)
  rejectionLow: number;   // low candle rejection (untuk SL bullish)
  entryPrice: number;     // entry lebih presisi dari rejection candle
  volumeConfirmed: boolean; // volume candle rejection > 1.2x rata-rata
  volumeRatio: number;      // rasio volume vs rata-rata
}

export function checkRejection15M(
  refinedZone: RefinedZone,
  opens15m: number[],
  highs15m: number[],
  lows15m: number[],
  closes15m: number[],
  bias: "bullish" | "bearish",
  volumes15m: number[] = []
): Rejection15M {
  const zoneLow = refinedZone.low;
  const zoneHigh = refinedZone.high;
  const buffer = (zoneHigh - zoneLow) * 0.1; // 10% dari lebar zona

  // Exclude candle terakhir (live/belum close) supaya konsisten antara scan dan analisa
  // Cek 3 candle 15M terakhir (dari candle yang sudah close)
  const opens = opens15m.slice(0, -1);
  const highs = highs15m.slice(0, -1);
  const lows = lows15m.slice(0, -1);
  const closes = closes15m.slice(0, -1);
  const volumes = volumes15m.length > 0 ? volumes15m.slice(0, -1) : [];

  // Hitung rata-rata volume 20 candle terakhir (untuk volume konfirmasi)
  const volSlice = volumes.slice(-20);
  const avgVolume = volSlice.length > 0
    ? volSlice.reduce((a, b) => a + b, 0) / volSlice.length
    : 0;

  const start = Math.max(0, opens.length - 3);

  for (let i = opens.length - 1; i >= start; i--) {
    const isInZone = lows[i] <= zoneHigh + buffer && highs[i] >= zoneLow - buffer;
    if (!isInZone) continue;

    const body = Math.abs(closes[i] - opens[i]);
    const range = highs[i] - lows[i];
    if (range === 0) continue;

    const upperWick = highs[i] - Math.max(opens[i], closes[i]);
    const lowerWick = Math.min(opens[i], closes[i]) - lows[i];

    if (bias === "bullish") {
      // Hammer / Pin Bar: lower wick > 1.5x body DAN candle bullish
      const isHammer = lowerWick > body * 1.5 && closes[i] > opens[i];
      // Rejection kuat: lower wick > 60% dari range total
      const isStrongRejection = lowerWick > range * 0.6;

      if (isHammer || isStrongRejection) {
        const entryPrice = lows[i] + range * 0.1;
        const volRatio = avgVolume > 0 && volumes.length > i ? volumes[i] / avgVolume : 0;
        const volConfirmed = volRatio >= 1.2;
        const baseType = isHammer ? "Hammer 15M" : "Pin Bar 15M";
        return {
          confirmed: true,
          candleType: volConfirmed ? `${baseType} ✅ Vol ${volRatio.toFixed(1)}x` : baseType,
          rejectionHigh: highs[i],
          rejectionLow: lows[i],
          entryPrice: Math.max(entryPrice, zoneLow),
          volumeConfirmed: volConfirmed,
          volumeRatio: volRatio,
        };
      }
    } else {
      // Shooting Star: upper wick > 1.5x body DAN candle bearish
      const isShootingStar = upperWick > body * 1.5 && closes[i] < opens[i];
      // Rejection kuat: upper wick > 60% dari range total
      const isStrongRejection = upperWick > range * 0.6;

      if (isShootingStar || isStrongRejection) {
        const entryPrice = highs[i] - range * 0.1;
        const volRatio = avgVolume > 0 && volumes.length > i ? volumes[i] / avgVolume : 0;
        const volConfirmed = volRatio >= 1.2;
        const baseType = isShootingStar ? "Shooting Star 15M" : "Pin Bar 15M";
        return {
          confirmed: true,
          candleType: volConfirmed ? `${baseType} ✅ Vol ${volRatio.toFixed(1)}x` : baseType,
          rejectionHigh: highs[i],
          rejectionLow: lows[i],
          entryPrice: Math.min(entryPrice, zoneHigh),
          volumeConfirmed: volConfirmed,
          volumeRatio: volRatio,
        };
      }
    }
  }

  return {
    confirmed: false,
    candleType: "Belum ada rejection 15M",
    rejectionHigh: refinedZone.high,
    rejectionLow: refinedZone.low,
    entryPrice: refinedZone.entryPrice,
    volumeConfirmed: false,
    volumeRatio: 0,
  };
}

export function checkEntryConfirmation5M(
  refinedZone: RefinedZone,
  opens5m: number[],
  highs5m: number[],
  lows5m: number[],
  closes5m: number[],
  bias: "bullish" | "bearish"
): EntryConfirmation {
  const zoneLow = refinedZone.low;
  const zoneHigh = refinedZone.high;

  // Check last 10 candles for confirmation
  const start = Math.max(0, opens5m.length - 10);

  for (let i = opens5m.length - 1; i >= start; i--) {
    const isInZone =
      lows5m[i] <= zoneHigh && highs5m[i] >= zoneLow;
    if (!isInZone) continue;

    if (bias === "bullish") {
      const candleRange = highs5m[i] - lows5m[i];
      const bodySize = Math.abs(closes5m[i] - opens5m[i]);
      const lowerWick = Math.min(opens5m[i], closes5m[i]) - lows5m[i];
      const upperWick = highs5m[i] - Math.max(opens5m[i], closes5m[i]);

      // Pin bar (hammer)
      if (lowerWick > candleRange * 0.6 && candleRange > 0) {
        return { confirmed: true, candleType: "Pin Bar (Hammer)", entryPrice: refinedZone.entryPrice };
      }
      // Bullish engulfing
      if (
        i > 0 &&
        closes5m[i] > opens5m[i] &&
        closes5m[i] > opens5m[i - 1] &&
        opens5m[i] < closes5m[i - 1] &&
        closes5m[i - 1] < opens5m[i - 1]
      ) {
        return { confirmed: true, candleType: "Bullish Engulfing", entryPrice: refinedZone.entryPrice };
      }
      // Rejection candle: bullish close with lower wick
      if (closes5m[i] > opens5m[i] && lowerWick > bodySize) {
        return { confirmed: true, candleType: "Rejection Candle", entryPrice: refinedZone.entryPrice };
      }
    } else {
      const candleRange = highs5m[i] - lows5m[i];
      const bodySize = Math.abs(closes5m[i] - opens5m[i]);
      const upperWick = highs5m[i] - Math.max(opens5m[i], closes5m[i]);
      const lowerWick = Math.min(opens5m[i], closes5m[i]) - lows5m[i];

      // Shooting star
      if (upperWick > candleRange * 0.6 && candleRange > 0) {
        return { confirmed: true, candleType: "Shooting Star", entryPrice: refinedZone.entryPrice };
      }
      // Bearish engulfing
      if (
        i > 0 &&
        closes5m[i] < opens5m[i] &&
        closes5m[i] < opens5m[i - 1] &&
        opens5m[i] > closes5m[i - 1] &&
        closes5m[i - 1] > opens5m[i - 1]
      ) {
        return { confirmed: true, candleType: "Bearish Engulfing", entryPrice: refinedZone.entryPrice };
      }
      // Rejection candle
      if (closes5m[i] < opens5m[i] && upperWick > bodySize) {
        return { confirmed: true, candleType: "Rejection Candle", entryPrice: refinedZone.entryPrice };
      }
    }
  }

  return { confirmed: false, candleType: "Belum ada konfirmasi 5M", entryPrice: refinedZone.entryPrice };
}

// ─── Step 5: Calculate SL, TP, Timing ────────────────────────────────────────

  export function calcSniperLevels(
    entryPrice: number,
    refinedZone: RefinedZone,
    atrSl: number,     // ATR D1 untuk SL
    atrH4: number,
    bias: "bullish" | "bearish",
    h1Highs: number[],
    h1Lows: number[],
    atrH1: number,
    d1Highs: number[] = [],
    d1Lows: number[] = [],
): SniperLevels {
    let stopLoss: number;

    // SL berdasarkan swing high/low D1 terdekat (20 candle lookback = 20 hari)
    const d1HighsToUse = d1Highs.length >= 3 ? d1Highs : h1Highs;
    const d1LowsToUse = d1Lows.length >= 3 ? d1Lows : h1Lows;
    const swingHighs = findSwingHighs(d1HighsToUse, 10);
    const swingLows = findSwingLows(d1LowsToUse, 10);
    const buffer = atrSl * 0.2; // buffer 20% ATR D1

    if (bias === "bullish") {
      // Cari swing low D1 terdekat di bawah entry
      const relevantLows = swingLows.filter(l => l < entryPrice);
      const nearestSwingLow = relevantLows.length > 0
        ? Math.max(...relevantLows)
        : Math.min(...d1LowsToUse.slice(-10));
      const rawSl = nearestSwingLow - buffer;
      // Minimum SL = 1x ATR D1 dari entry
      const minSl = entryPrice - atrSl;
      stopLoss = Math.min(rawSl, minSl);
    } else {
      // Cari swing high D1 terdekat di atas entry
      const relevantHighs = swingHighs.filter(h => h > entryPrice);
      const nearestSwingHigh = relevantHighs.length > 0
        ? Math.min(...relevantHighs)
        : Math.max(...d1HighsToUse.slice(-10));
      const rawSl = nearestSwingHigh + buffer;
      // Minimum SL = 1x ATR D1 dari entry
      const minSl = entryPrice + atrSl;
      stopLoss = Math.max(rawSl, minSl);
    }

  const riskAmount = Math.abs(entryPrice - stopLoss);

  const takeProfit1 =
    bias === "bullish"
      ? entryPrice + riskAmount * 1.5
      : entryPrice - riskAmount * 1.5;

  const takeProfit2 =
    bias === "bullish"
      ? entryPrice + riskAmount * 3
      : entryPrice - riskAmount * 3;

  // Timing estimates
    const setupValidHours = Math.round((atrH4 / atrSl) * 2);
  const distanceToEntry = Math.abs(entryPrice - 0); // placeholder - calculated per call
    const estimatedHitHours = Math.round((atrSl > 0 ? Math.abs(entryPrice) / atrSl : 1) * 1);
  const expiryHours = setupValidHours + 4;

  return {
    entryPrice,
    stopLoss,
    takeProfit1,
    takeProfit2,
    riskAmount,
    setupValidHours: Math.max(2, setupValidHours),
    estimatedHitHours: Math.max(1, Math.min(estimatedHitHours, setupValidHours)),
    expiryHours: Math.max(6, expiryHours),
  };
}

// ─── Step 6: Skip Conditions ──────────────────────────────────────────────────

// CHoCH: detects if H1 has broken structure against the bias (change of character)
// Bullish: close breaks below most recent swing low → CHoCH formed → skip
// Bearish: close breaks above most recent swing high → CHoCH formed → skip
function detectCHoCH(
  highs: number[],
  lows: number[],
  closes: number[],
  bias: "bullish" | "bearish"
): boolean {
  const lastClose = closes[closes.length - 1];
  if (bias === "bullish") {
    const swingLows = findSwingLows(lows, 5);
    if (swingLows.length < 1) return false;
    const recentHL = swingLows[swingLows.length - 1];
    return lastClose < recentHL;
  } else {
    const swingHighs = findSwingHighs(highs, 5);
    if (swingHighs.length < 1) return false;
    const recentLH = swingHighs[swingHighs.length - 1];
    return lastClose > recentLH;
  }
}

// CHoCH 15M: deteksi CHoCH yang SEARAH bias (konfirmasi, bukan skip)
// Bullish: harga sebelumnya bikin LL, lalu breakout bikin HH → struktur mulai bullish
// Bearish: harga sebelumnya bikin HH, lalu breakdown bikin LL → struktur mulai bearish
function detectCHoCH15M(
  highs: number[],
  lows: number[],
  closes: number[],
  bias: "bullish" | "bearish"
): { detected: boolean; description: string } {
  // Exclude candle terakhir (live/belum close) supaya konsisten antara scan dan analisa
  const h = highs.slice(0, -1);
  const l = lows.slice(0, -1);
  const c = closes.slice(0, -1);
  const n = c.length;
  if (n < 10) return { detected: false, description: "Data tidak cukup" };

  // Ambil 20 candle terakhir
  const sliceH = h.slice(Math.max(0, n - 20));
  const sliceL = l.slice(Math.max(0, n - 20));
  const sliceC = c.slice(Math.max(0, n - 20));

  const swingHighs = findSwingHighs(sliceH, 3);
  const swingLows = findSwingLows(sliceL, 3);

  const lastClose = sliceC[sliceC.length - 1];

  if (bias === "bullish") {
    // CHoCH bullish: sebelumnya ada LL, lalu close breakout di atas HH terakhir
    if (swingHighs.length < 2 || swingLows.length < 2) return { detected: false, description: "Swing tidak cukup" };

    const prevHH = swingHighs[swingHighs.length - 2];
    const lastHH = swingHighs[swingHighs.length - 1];
    const prevLL = swingLows[swingLows.length - 2];
    const lastLL = swingLows[swingLows.length - 1];

    // Struktur sebelumnya bearish (LL terbentuk)
    const hadBearStructure = lastLL < prevLL;
    // Sekarang close breakout di atas HH sebelumnya
    const chochConfirmed = lastClose > prevHH;

    if (hadBearStructure && chochConfirmed) {
      return {
        detected: true,
        description: `CHoCH Bullish 15M — LL terbentuk di ${lastLL.toFixed(4)}, close breakout HH ${prevHH.toFixed(4)}`
      };
    }
  } else {
    // CHoCH bearish: sebelumnya ada HH, lalu close breakdown di bawah LL terakhir
    if (swingHighs.length < 2 || swingLows.length < 2) return { detected: false, description: "Swing tidak cukup" };

    const prevHH = swingHighs[swingHighs.length - 2];
    const lastHH = swingHighs[swingHighs.length - 1];
    const prevLL = swingLows[swingLows.length - 2];
    const lastLL = swingLows[swingLows.length - 1];

    // Struktur sebelumnya bullish (HH terbentuk)
    const hadBullStructure = lastHH > prevHH;
    // Sekarang close breakdown di bawah LL sebelumnya
    const chochConfirmed = lastClose < prevLL;

    if (hadBullStructure && chochConfirmed) {
      return {
        detected: true,
        description: `CHoCH Bearish 15M — HH terbentuk di ${lastHH.toFixed(4)}, close breakdown LL ${prevLL.toFixed(4)}`
      };
    }
  }

  return { detected: false, description: "CHoCH 15M belum terbentuk" };
}

// ─── Teori Dow: Deteksi Fase Trend ───────────────────────────────────────────

function detectDowPhase(
  highs: number[],
  lows: number[],
  closes: number[],
  volumes: number[],
  bias: "bullish" | "bearish"
): { phase: DowPhase; description: string } {
  const n = closes.length;
  if (n < 30) return { phase: 'unknown', description: 'Data tidak cukup' };

  // Bagi data jadi 3 bagian (awal, tengah, akhir)
  const third = Math.floor(n / 3);
  const early = { closes: closes.slice(0, third), volumes: volumes.slice(0, third) };
  const mid   = { closes: closes.slice(third, third * 2), volumes: volumes.slice(third, third * 2) };
  const late  = { closes: closes.slice(third * 2), volumes: volumes.slice(third * 2) };

  const avgVolEarly = early.volumes.reduce((a, b) => a + b, 0) / early.volumes.length;
  const avgVolMid   = mid.volumes.reduce((a, b) => a + b, 0) / mid.volumes.length;
  const avgVolLate  = late.volumes.reduce((a, b) => a + b, 0) / late.volumes.length;

  // Price change per periode
  const priceChangeMid  = (mid.closes[mid.closes.length - 1] - mid.closes[0]) / mid.closes[0] * 100;
  const priceChangeLate = (late.closes[late.closes.length - 1] - late.closes[0]) / late.closes[0] * 100;

  // Volume trend: naik atau turun dari periode ke periode
  const volAccelerating = avgVolMid > avgVolEarly * 1.1 && avgVolLate > avgVolMid * 1.1;
  const volDecelerating = avgVolLate < avgVolMid * 0.85;

  if (bias === "bullish") {
    // Accumulation: harga sideways/naik perlahan, volume rendah dan stabil
    if (Math.abs(priceChangeMid) < 5 && avgVolMid <= avgVolEarly * 1.1) {
      return { phase: 'accumulation', description: `Accumulation — harga konsolidasi, volume stabil (${avgVolLate.toFixed(0)} avg)` };
    }
    // Distribution: harga masih naik tapi volume turun (divergence)
    if (priceChangeLate > 2 && volDecelerating) {
      return { phase: 'distribution', description: `Distribution — harga naik tapi volume melemah (vol turun ${((1 - avgVolLate/avgVolMid)*100).toFixed(0)}%)` };
    }
    // Public participation: harga naik kuat dengan volume naik
    if (priceChangeMid > 3 && volAccelerating) {
      return { phase: 'participation', description: `Public Participation — harga naik kuat dengan volume menguat` };
    }
  } else {
    // Accumulation (bearish): harga sideways/turun perlahan, volume rendah
    if (Math.abs(priceChangeMid) < 5 && avgVolMid <= avgVolEarly * 1.1) {
      return { phase: 'accumulation', description: `Accumulation — harga konsolidasi bearish, volume stabil` };
    }
    // Distribution (bearish): harga turun tapi volume melemah = potensi reversal
    if (priceChangeLate < -2 && volDecelerating) {
      return { phase: 'distribution', description: `Distribution — harga turun tapi volume melemah (potensi reversal)` };
    }
    // Public participation bearish: harga turun kuat dengan volume naik
    if (priceChangeMid < -3 && volAccelerating) {
      return { phase: 'participation', description: `Public Participation — harga turun kuat dengan volume menguat` };
    }
  }

  return { phase: 'unknown', description: 'Fase tidak terdeteksi jelas' };
}

// ─── Teori Dow: Volume Konfirmasi Trend ──────────────────────────────────────

function checkVolumeTrend(
  closes: number[],
  volumes: number[],
  bias: "bullish" | "bearish"
): { valid: boolean; description: string } {
  const n = closes.length;
  if (n < 20 || volumes.length < 20) return { valid: true, description: 'Data tidak cukup' };

  // Pisahkan candle impulse (searah bias) dan candle pullback (berlawanan)
  const recent = closes.slice(-20);
  const recentVols = volumes.slice(-20);

  let impulseVol = 0, impulseCount = 0;
  let pullbackVol = 0, pullbackCount = 0;

  for (let i = 1; i < recent.length; i++) {
    const isUp = recent[i] > recent[i - 1];
    if ((bias === 'bullish' && isUp) || (bias === 'bearish' && !isUp)) {
      impulseVol += recentVols[i];
      impulseCount++;
    } else {
      pullbackVol += recentVols[i];
      pullbackCount++;
    }
  }

  const avgImpulseVol  = impulseCount  > 0 ? impulseVol  / impulseCount  : 0;
  const avgPullbackVol = pullbackCount > 0 ? pullbackVol / pullbackCount : 0;

  // Volume Dow: impulse candle harus lebih tinggi volumenya dari pullback
  const ratio = avgPullbackVol > 0 ? avgImpulseVol / avgPullbackVol : 1;
  const valid = ratio >= 1.0; // impulse vol >= pullback vol

  if (valid) {
    return { valid: true, description: `Volume trend valid — impulse vol ${ratio.toFixed(1)}x vs pullback` };
  } else {
    return { valid: false, description: `Volume melemah — pullback vol lebih tinggi dari impulse (${ratio.toFixed(1)}x)` };
  }
}

export async function checkSkipConditions(
  symbol: string,
  bias: "bullish" | "bearish",
  h1Closes: number[],
  h1Highs: number[],
  h1Lows: number[],
  h4Highs: number[] = [],
  h4Lows: number[] = [],
  h4Closes: number[] = [],
  h4Volumes: number[] = [],
): Promise<SkipConditions> {
  const reasons: string[] = [];
  let shouldSkip = false;

  // 1. RSI
  const rsi = calcRSI(h1Closes);
  let rsiDivergence = false;

  // Detect divergence: check last 5 candles
  const recentCloses = h1Closes.slice(-10);
  const recentHighs = h1Highs.slice(-10);
  const recentLows = h1Lows.slice(-10);

  // Calculate RSI for first half and second half
  const firstRsi = calcRSI(h1Closes.slice(0, -5));
  const secondRsi = calcRSI(h1Closes);

  if (bias === "bullish") {
    // Bearish divergence on bullish bias: price makes HH but RSI makes LH
    const priceHigher = recentHighs[recentHighs.length - 1] > recentHighs[recentHighs.length - 6];
    if (priceHigher && secondRsi < firstRsi * 0.95) {
      rsiDivergence = true;
      reasons.push("RSI divergence terdeteksi di H1 (harga HH tapi RSI LH)");
      shouldSkip = true;
    }
  } else {
    // Bullish divergence on bearish bias: price makes LL but RSI makes HL
    const priceLower = recentLows[recentLows.length - 1] < recentLows[recentLows.length - 6];
    if (priceLower && secondRsi > firstRsi * 1.05) {
      rsiDivergence = true;
      reasons.push("RSI divergence terdeteksi di H1 (harga LL tapi RSI HL)");
      shouldSkip = true;
    }
  }

  // CHoCH H1 dihapus dari skip condition — justru ini yang kita cari (koreksi/pullback)
  const chochDetected = detectCHoCH(h1Highs, h1Lows, h1Closes, bias);

  // CHoCH H4 dihapus — sudah dicek di Step 1 (trend H4 harus valid sebelum masuk sini)
  const chochH4Detected = false;

  // 2c. Dow Phase Detection
  const dowResult = h4Closes.length > 0
    ? detectDowPhase(h4Highs, h4Lows, h4Closes, h4Volumes, bias)
    : { phase: 'unknown' as DowPhase, description: 'Data H4 tidak tersedia' };

  // Distribution phase = sinyal bahaya, skip
  if (dowResult.phase === 'distribution') {
    reasons.push(`Fase Distribution terdeteksi di H4 — ${dowResult.description}`);
    shouldSkip = true;
  }

  // 2d. Volume Trend (Teori Dow: volume harus konfirmasi trend)
  const volTrend = h4Closes.length > 0
    ? checkVolumeTrend(h4Closes, h4Volumes, bias)
    : { valid: true, description: 'Data volume tidak tersedia' };

  return {
    shouldSkip, reasons, rsi, rsiDivergence,
    chochDetected, chochH4Detected,
    oiChange: 0, oiAccumulation: false, oiAccumulationDesc: '',
    fundingRate: 0,
    dowPhase: dowResult.phase,
    dowPhaseDesc: dowResult.description,
    volumeTrendValid: volTrend.valid,
    volumeTrendDesc: volTrend.description,
  };
}

// ─── Main Analysis Function ───────────────────────────────────────────────────

// ─── Multi-TF Confluence: H4 approaching H1 zone ─────────────────────────────

function detectH4Confluence(
  h4Highs: number[],
  h4Lows: number[],
  h4Closes: number[],
  h4Volumes: number[],
  zoneLow: number,
  zoneHigh: number,
  bias: "bullish" | "bearish"
): { confirmed: boolean; strength: "strong" | "moderate" | "weak"; description: string } {
  const n = h4Closes.length;
  if (n < 10) return { confirmed: false, strength: "weak", description: "Data H4 tidak cukup" };

  const lastClose = h4Closes[n - 1];
  const zoneRange = zoneHigh - zoneLow;
  const zoneMid = (zoneHigh + zoneLow) / 2;

  // Jarak harga H4 ke tepi zona (sebagai % dari harga)
  const distToZone = bias === "bullish"
    ? (lastClose - zoneHigh) / lastClose * 100   // jarak ke atas zona (bullish: approaching dari atas)
    : (zoneLow - lastClose) / lastClose * 100;    // jarak ke bawah zona (bearish: approaching dari bawah)

  // Tidak confluence kalau harga sudah di dalam zona atau sudah lewat
  if (distToZone < 0) {
    return { confirmed: false, strength: "weak", description: "Harga H4 sudah melewati zona" };
  }

  // Cek apakah H4 sedang bergerak menuju zona (momentum searah)
  const last5Closes = h4Closes.slice(-5);
  const isApproaching = bias === "bullish"
    ? last5Closes[last5Closes.length - 1] < last5Closes[0]  // harga turun menuju zona support
    : last5Closes[last5Closes.length - 1] > last5Closes[0]; // harga naik menuju zona resistance

  // Cek volume H4 saat approaching (harus melemah = pullback sehat)
  const recentVols = h4Volumes.slice(-5);
  const avgVol = h4Volumes.slice(-20).reduce((a, b) => a + b, 0) / Math.min(20, h4Volumes.length);
  const lastVol = recentVols[recentVols.length - 1];
  const pullbackHealthy = lastVol < avgVol * 0.9; // volume pullback < rata-rata = sehat

  // Kekuatan confluence berdasarkan jarak dan kondisi
  if (distToZone <= 1.0 && isApproaching && pullbackHealthy) {
    return {
      confirmed: true,
      strength: "strong",
      description: `H4 approaching zona (${distToZone.toFixed(2)}% jauh), pullback volume sehat`
    };
  } else if (distToZone <= 2.5 && isApproaching) {
    return {
      confirmed: true,
      strength: "moderate",
      description: `H4 menuju zona (${distToZone.toFixed(2)}% jauh), momentum approaching`
    };
  } else if (distToZone <= 5.0) {
    return {
      confirmed: true,
      strength: "weak",
      description: `H4 dalam radius zona (${distToZone.toFixed(2)}% jauh)`
    };
  }

  return { confirmed: false, strength: "weak", description: `H4 masih jauh dari zona (${distToZone.toFixed(2)}%)` };
}

export async function analyzeSniperEntry(symbol: string): Promise<SniperResult> {
  const timestamp = new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    hour: '2-digit',
    minute: '2-digit',
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  }) + ' WIB';

  try {
    // Fetch all data in parallel
    const [d1, h4, h1, m15, m5, currentTickerRes] = await Promise.all([
      fetchKlines(symbol, "1d", 30),   // D1 — trend utama
      fetchKlines(symbol, "4h", 100),  // H4 — zona entry
      fetchKlines(symbol, "1h", 50),   // H1 — refine zona
      fetchKlines(symbol, "15m", 100), // 15M — refine lebih presisi
      fetchKlines(symbol, "5m", 200),  // 5M — entry presisi
      fetch(`${BINANCE_FUTURES_BASE}/fapi/v1/ticker/price?symbol=${symbol}`),
    ]);

    let currentPrice: number;
    if (currentTickerRes.ok) {
      const ticker: { price: string } = await currentTickerRes.json();
      currentPrice = parseFloat(ticker.price);
    } else {
      currentPrice = h1.closes[h1.closes.length - 1];
    }

    // STEP 1: Confirm trend D1 (trend utama)
    const structD1 = analyzePriceActionStructure(d1.highs, d1.lows, d1.closes);

    if (structD1.bias === "ranging") {
      return {
        status: "no_trend",
        message: `Struktur D1 ranging, tidak ada trend jelas untuk ${symbol}`,
        symbol,
        currentPrice,
        timestamp,
        h4: { bias: structD1.bias, strength: structD1.strength },
      };
    }

    const bias = structD1.bias as "bullish" | "bearish";
    // Catat juga struktur H4 untuk info
    const structH4 = analyzePriceActionStructure(h4.highs, h4.lows, h4.closes);

    // STEP 2: Detect zones at H4 (zona entry utama, lebih besar dari H1)
    const [obs, fvgs, unfilledOrders] = await Promise.all([
      Promise.resolve(detectOrderBlocksH1(h4.opens, h4.highs, h4.lows, h4.closes, bias)),
      Promise.resolve(detectFVGH1(h4.highs, h4.lows, bias)),
      detectUnfilledOrdersH1(symbol, currentPrice, bias),
    ]);

    const srLevels = detectSRLevels(h4.highs, h4.lows, h4.closes);
    const sndZones = detectSnDZones(h4.opens, h4.highs, h4.lows, h4.closes);
    const fibLevels = calcFibonacci(d1.highs, d1.lows, d1.closes);

    const selectedZone = selectBestZoneH1(
      obs, fvgs, unfilledOrders, srLevels, sndZones, fibLevels, bias, currentPrice
    );

    if (!selectedZone) {
      return {
        status: "no_zone",
        message: `Trend H4 valid (${bias}) tapi belum ada zona OB/FVG/S&R yang cukup kuat di H1`,
        symbol,
        currentPrice,
        timestamp,
        bias,
        h4: { bias: structD1.bias, strength: structD1.strength }, // D1 trend
        h4Actual: { bias: structH4.bias, strength: structH4.strength }, // H4 info
      };
    }

    // STEP 3: Check skip conditions (after zone found)
    const skipConds = await checkSkipConditions(
      symbol, bias,
      d1.closes, d1.highs, d1.lows,
      d1.highs, d1.lows, d1.closes, d1.volumes
    );

    if (skipConds.shouldSkip) {
      return {
        status: "skip_conditions",
        message: `Zona ditemukan tapi ada kondisi yang tidak mendukung untuk ${symbol}`,
        symbol,
        currentPrice,
        timestamp,
        bias,
        h4: { bias: structD1.bias, strength: structD1.strength }, // D1 trend utama
      h4Actual: { bias: structH4.bias, strength: structH4.strength }, // H4 info tambahan
        zoneType: selectedZone.zoneType,
        rsi: skipConds.rsi,
        rsiDivergence: skipConds.rsiDivergence,
        chochDetected: skipConds.chochDetected,
        oiChange: skipConds.oiChange,
        fundingRate: skipConds.fundingRate,
        skipReasons: skipConds.reasons,
      };
    }

    // STEP 3: Refine zona H4 → H1 → 15M → 5M
    // Cari konfluens terkuat: OB > FVG > S&R > Fib > UFO per TF
    // Step 3a: H4 zona → cari yang terkuat di H1
    const zoneH1 = findBestZoneInRange(
      h1.opens, h1.highs, h1.lows, h1.closes, h1.volumes,
      bias, selectedZone.low, selectedZone.high, "H1", selectedZone.zoneType, currentPrice
    );
    const zoneForRefine = zoneH1 ?? { ...selectedZone, refined: false };

    // Step 3b: H1 zona → refine ke 15M → 5M
    const refinedZone = refineZoneMultiTF(
      zoneForRefine,
      m15.opens, m15.highs, m15.lows, m15.closes, m15.volumes,
      m5.opens, m5.highs, m5.lows, m5.closes, m5.volumes,
      bias, currentPrice
    );

    // STEP 4a: Multi-TF Confluence — H4 approaching H1 zone
    const h4Confluence = detectH4Confluence(
      d1.highs, d1.lows, d1.closes, d1.volumes,
      selectedZone.low, selectedZone.high, bias
    );

    // STEP 4b: CHoCH 15M (scoring, bukan hard filter)
    const choch15M = detectCHoCH15M(m15.highs, m15.lows, m15.closes, bias);

    // STEP 4b: Rejection candle 15M (scoring, bukan hard filter)
    const rejection15M = checkRejection15M(
      refinedZone, m15.opens, m15.highs, m15.lows, m15.closes, bias, m15.volumes
    );

    // STEP 4c: Pattern konfirmasi 15M/5M (scoring, bukan hard filter)
    const validPatterns = bias === "bullish"
      ? ["Bull Flag", "Ascending Triangle", "Double Bottom", "Inverse H&S", "Falling Wedge", "Pennant"]
      : ["Bear Flag", "Descending Triangle", "Double Top", "Head & Shoulders", "Rising Wedge", "Pennant"];

    const allPatterns = [
      detectBullFlag(m15.highs, m15.lows, m15.closes, m15.volumes),
      detectBearFlag(m15.highs, m15.lows, m15.closes, m15.volumes),
      detectAscendingTriangle(m15.highs, m15.lows, m15.closes),
      detectDescendingTriangle(m15.highs, m15.lows, m15.closes),
      detectDoubleBottom(m15.highs, m15.lows, m15.closes),
      detectDoubleTop(m15.highs, m15.lows, m15.closes),
      detectInverseHS(m15.highs, m15.lows, m15.closes),
      detectHeadAndShoulders(m15.highs, m15.lows, m15.closes),
      detectFallingWedge(m15.highs, m15.lows, m15.closes),
      detectRisingWedge(m15.highs, m15.lows, m15.closes),
      detectPennant(m15.highs, m15.lows, m15.closes, m15.volumes),
      detectBullFlag(m5.highs, m5.lows, m5.closes, m5.volumes),
      detectBearFlag(m5.highs, m5.lows, m5.closes, m5.volumes),
      detectAscendingTriangle(m5.highs, m5.lows, m5.closes),
      detectDescendingTriangle(m5.highs, m5.lows, m5.closes),
      detectDoubleBottom(m5.highs, m5.lows, m5.closes),
      detectDoubleTop(m5.highs, m5.lows, m5.closes),
    ].filter(p => p !== null && validPatterns.includes(p!.name));
    const confirmedPattern = allPatterns.length > 0 ? allPatterns[0] : null;



    // STEP 4e: Konfirmasi 5M
    const confirmation = checkEntryConfirmation5M(
      refinedZone, m5.opens, m5.highs, m5.lows, m5.closes, bias
    );

    // STEP 5: Probability scoring
    let profitProbability = 0;
    const probabilityFactors: string[] = [];

    if (choch15M.detected) {
      profitProbability += 30;
      probabilityFactors.push("✅ CHoCH 15M terkonfirmasi (+30%)");
    } else {
      probabilityFactors.push("⚠️ CHoCH 15M belum terbentuk");
    }

    if (rejection15M.confirmed) {
      if (rejection15M.volumeConfirmed) {
        profitProbability += 25;
        probabilityFactors.push(`✅ Rejection 15M + Volume: ${rejection15M.candleType} (+25%)`);
      } else {
        profitProbability += 15;
        probabilityFactors.push(`✅ Rejection 15M: ${rejection15M.candleType} (+15%) — volume lemah`);
      }
    } else {
      probabilityFactors.push("⚠️ Tidak ada rejection candle 15M di zona");
    }

    if (confirmedPattern) {
      profitProbability += 20;
      probabilityFactors.push(`✅ Pattern: ${confirmedPattern.name} (+20%)`);
    } else {
      probabilityFactors.push("⚠️ Tidak ada pattern konfirmasi");
    }

    // Jam sesi dihapus — crypto 24 jam, jam tidak relevan

    if (selectedZone.tier <= 2) {
      profitProbability += 10;
      probabilityFactors.push(`✅ Zona Tier ${selectedZone.tier} (+10%)`);
    } else {
      probabilityFactors.push(`⚠️ Zona Tier ${selectedZone.tier} (Tier 1-2 lebih baik)`);
    }

    // Fresh zone check — zona yang belum pernah disentuh lebih kuat
    const zoneTouches = selectedZone.touches ?? 0;
    if (zoneTouches === 0) {
      probabilityFactors.push(`✅ Zona fresh — belum pernah ditest`);
    } else if (zoneTouches === 1) {
      probabilityFactors.push(`⚠️ Zona sudah disentuh 1x — masih valid`);
    } else {
      probabilityFactors.push(`🚫 Zona sudah disentuh ${zoneTouches}x — kekuatan berkurang`);
    }

    // Teori Dow: fase trend
    if (skipConds.dowPhase === 'accumulation') {
      profitProbability += 10;
      probabilityFactors.push(`✅ Fase Dow: Accumulation (+10%) — ${skipConds.dowPhaseDesc}`);
    } else if (skipConds.dowPhase === 'participation') {
      profitProbability += 5;
      probabilityFactors.push(`✅ Fase Dow: Public Participation (+5%) — ${skipConds.dowPhaseDesc}`);
    } else if (skipConds.dowPhase === 'unknown') {
      probabilityFactors.push(`⚠️ Fase Dow tidak teridentifikasi`);
    }

    // Teori Dow: volume konfirmasi trend
    if (skipConds.volumeTrendValid) {
      profitProbability += 5;
      probabilityFactors.push(`✅ Volume Dow valid (+5%) — ${skipConds.volumeTrendDesc}`);
    } else {
      probabilityFactors.push(`⚠️ Volume Dow lemah — ${skipConds.volumeTrendDesc}`);
    }

    // Multi-TF Confluence: H4 approaching H1 zone
    if (h4Confluence.confirmed) {
      if (h4Confluence.strength === "strong") {
        profitProbability += 15;
        probabilityFactors.push(`✅ H4 Confluence KUAT (+15%) — ${h4Confluence.description}`);
      } else if (h4Confluence.strength === "moderate") {
        profitProbability += 10;
        probabilityFactors.push(`✅ H4 Confluence SEDANG (+10%) — ${h4Confluence.description}`);
      } else {
        profitProbability += 5;
        probabilityFactors.push(`✅ H4 Confluence LEMAH (+5%) — ${h4Confluence.description}`);
      }
    } else {
      probabilityFactors.push(`⚠️ Tidak ada H4 confluence — ${h4Confluence.description}`);
    }

    // Entry price: pakai rejection 15M kalau ada, fallback ke zona entry
    const finalEntryPrice = rejection15M.confirmed
      ? rejection15M.entryPrice
      : refinedZone.entryPrice;

    // STEP 6: Calculate SL/TP
    const atrH1 = calcATR(h1.highs, h1.lows, h1.closes);
    const atrD1 = calcATR(d1.highs, d1.lows, d1.closes); // ATR D1 untuk SL
    const atrH4 = calcATR(h4.highs, h4.lows, h4.closes); // ATR H4 untuk estimasi waktu

    const sniperLevels = calcSniperLevels(
      finalEntryPrice, refinedZone, atrD1, atrD1, bias,
      d1.highs, d1.lows, atrD1, // swing D1 untuk SL
      d1.highs, d1.lows
    );

    // Estimate time to hit entry (pakai atrH4 untuk estimasi jam)
    const distanceToEntry = Math.abs(currentPrice - sniperLevels.entryPrice);
    const estimatedHitHours = Math.max(1, Math.round(distanceToEntry / atrH4));

    // Build reasoning
    const reasoning = [
      `Entry di ${selectedZone.zoneType} (${selectedZone.low.toFixed(4)}-${selectedZone.high.toFixed(4)}).`,
      refinedZone.refined ? `Direfine menggunakan ${refinedZone.zoneType}.` : "Zona H1 digunakan langsung.",
      choch15M.detected ? `✅ ${choch15M.description}.` : "⏳ CHoCH 15M belum terbentuk.",
      rejection15M.confirmed
        ? `✅ Rejection 15M: ${rejection15M.candleType} — entry limit di ${finalEntryPrice.toFixed(4)}.`
        : "⏳ Belum ada rejection 15M — limit order di tengah zona.",
      confirmedPattern ? `✅ Pattern: ${confirmedPattern.name}.` : "⏳ Tidak ada pattern konfirmasi.",
      confirmation.confirmed ? `Konfirmasi 5M: ${confirmation.candleType}.` : "",
      `SL di ${bias === "bullish" ? "bawah" : "atas"} swing H1 terdekat.`,
      `TP1 R:R 1:1.5, TP2 R:R 1:3.`,
    ].filter(Boolean).join(" ");

    return {
      status: "ready",
      message: `Setup sniper tersedia untuk ${symbol}`,
      symbol,
      currentPrice,
      timestamp,
      bias,
      entryPrice: sniperLevels.entryPrice,
      stopLoss: sniperLevels.stopLoss,
      takeProfit1: sniperLevels.takeProfit1,
      takeProfit2: sniperLevels.takeProfit2,
      h4: { bias: structD1.bias, strength: structD1.strength }, // D1 trend utama
      h4Actual: { bias: structH4.bias, strength: structH4.strength }, // H4 zona info
      zoneType: selectedZone.zoneType,
      zoneRange: { low: selectedZone.low, high: selectedZone.high },
      refinedZoneType: refinedZone.zoneType,
      entryConfirmed: rejection15M.confirmed || confirmation.confirmed,
      confirmationCandle: rejection15M.confirmed
        ? rejection15M.candleType
        : confirmation.candleType,
      rejection15M: rejection15M.confirmed,
      rejection15MCandle: rejection15M.candleType,
      choch15M: choch15M.detected,
      choch15MDescription: choch15M.description,
      patternConfirmed: !!confirmedPattern,
      patternName: confirmedPattern?.name,
      profitProbability,
      probabilityFactors,
      dowPhase: skipConds.dowPhase,
      dowPhaseDesc: skipConds.dowPhaseDesc,
      volumeTrendValid: skipConds.volumeTrendValid,
      volumeTrendDesc: skipConds.volumeTrendDesc,
      chochH4Detected: skipConds.chochH4Detected,
      h4ConfluenceConfirmed: h4Confluence.confirmed,
      h4ConfluenceStrength: h4Confluence.strength,
      h4ConfluenceDesc: h4Confluence.description,
      rsi: skipConds.rsi,
      rsiDivergence: skipConds.rsiDivergence,
      chochDetected: skipConds.chochDetected,
      oiChange: skipConds.oiChange,
      oiAccumulation: skipConds.oiAccumulation,
      oiAccumulationDesc: skipConds.oiAccumulationDesc,
      fundingRate: skipConds.fundingRate,
      setupValidHours: sniperLevels.setupValidHours,
      estimatedHitHours,
      expiryHours: sniperLevels.expiryHours,
      reasoning,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return {
      status: "error",
      message: `Gagal menganalisa ${symbol}: ${message}`,
      symbol,
      currentPrice: 0,
      timestamp,
    };
  }
}
// ─── Menu 4: Breakout Detection ───────────────────────────────────────────────

// ─── Menu 6: Scalping Scanner (SMC Micro 15M) ────────────────────────────────

export interface ScalpingResult {
  status: 'waiting' | 'in_zone' | 'expired' | 'no_setup' | 'no_structure' | 'skip' | 'error';
  symbol: string;
  bias?: 'bullish' | 'bearish';
  currentPrice: number;
  timestamp: string;
  message?: string;
  score?: number;
  maxScore: number;
  // Struktur 15M
  structure15M?: string;
  choch15M?: boolean;
  // OB 5M
  ob5M?: { low: number; high: number; mid: number; fresh: boolean };
  // Levels
  entryPrice?: number;
  stopLoss?: number;
  takeProfit1?: number;
  takeProfit2?: number;
  rr1?: number;
  rr2?: number;
  // Info
  atr15MPct?: number;
  spreadEstPct?: number;
  filterResults?: string[];
}

export async function analyzeScalpingEntry(symbol: string): Promise<ScalpingResult> {
  const timestamp = new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit',
    day: '2-digit', month: 'long', year: 'numeric',
  }) + ' WIB';
  const maxScore = 7;

  // Helper: hitung EMA dari array closes
  function calcEMA(closes: number[], period: number): number {
    if (closes.length < period) return closes[closes.length - 1] ?? 0;
    const k = 2 / (period + 1);
    let ema = closes.slice(0, period).reduce((a, b) => a + b, 0) / period;
    for (let i = period; i < closes.length; i++) {
      ema = closes[i]! * k + ema * (1 - k);
    }
    return ema;
  }

  try {
    const [h4, h1, m30, m5, tickerRes] = await Promise.all([
      fetchKlines(symbol, '4h', 100),   // H4 — trend utama, EMA34, SL
      fetchKlines(symbol, '1h', 50),    // H1 — RSI divergence
      fetchKlines(symbol, '30m', 100),  // M30 — zona entry & pattern
      fetchKlines(symbol, '5m', 200),   // M5 — refine zona
      fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${symbol}`),
    ]);
    const currentPrice = tickerRes.ok
      ? parseFloat((await tickerRes.json() as { price: string }).price)
      : m30.closes[m30.closes.length - 1];

    const filterResults: string[] = [];
    let score = 0;
    let trendWarning = '';

    // ── Filter 1: Struktur H4 + konfirmasi EMA 34 H4 ─────────────────────
    const structH4 = analyzePriceActionStructure(h4.highs, h4.lows, h4.closes);
    if (structH4.bias === 'ranging') {
      return { status: 'skip', symbol, currentPrice, timestamp, message: 'H4 ranging — tidak ada trend utama yang jelas', score, maxScore, filterResults };
    }

    const bias = structH4.bias as 'bullish' | 'bearish';

    // EMA 34 H4 — opsional, bukan hard filter. Konfirmasi tambahan saja.
    const ema34H4 = calcEMA(h4.closes, 34);
    const lastCloseH4 = h4.closes[h4.closes.length - 1] ?? currentPrice;
    const emaConfirmed =
      (bias === 'bullish' && lastCloseH4 > ema34H4) ||
      (bias === 'bearish' && lastCloseH4 < ema34H4);

    score++;
    filterResults.push(
      `✅ Trend H4: ${bias === 'bullish' ? 'Bullish' : 'Bearish'} (${structH4.strength}) | EMA34 H4: ${ema34H4.toFixed(4)} ${emaConfirmed ? '✅ konfirmasi' : '⚠️ belum konfirmasi EMA'}`
    );

    // ── Filter 2: ATR D1 >= 0.5% (volatilitas cukup) ─────────────────────
    // Gunakan ATR H4 sebagai proxy volatilitas (gak fetch D1 lagi)
    const atrH4 = calcATR(h4.highs, h4.lows, h4.closes);
    const atrH4Pct = (atrH4 / currentPrice) * 100;
    if (atrH4Pct < 0.5) {
      return { status: 'skip', symbol, currentPrice, timestamp, message: `ATR H4 terlalu rendah (${atrH4Pct.toFixed(2)}%) — volatilitas tidak cukup untuk scalping`, score, maxScore, filterResults };
    }
    score++;
    filterResults.push(`✅ ATR H4 ${atrH4Pct.toFixed(2)}%`);

    // ── Cek M30 vs H4 — koreksi atau searah ──────────────────────────────
    const structM30 = analyzePriceActionStructure(m30.highs, m30.lows, m30.closes);
    const m30Correction = structM30.bias !== bias; // M30 berlawanan H4 = koreksi valid
    const m30Ranging = structM30.bias === 'ranging';
    if (!m30Correction && !m30Ranging) {
      trendWarning = `⚠️ M30 masih searah H4 (${structM30.bias}) — tunggu koreksi M30 sebelum entry`;
      filterResults.push(trendWarning);
    } else {
      score++;
      filterResults.push(`✅ M30 ${m30Ranging ? 'konsolidasi' : 'koreksi'} (${structM30.bias}) — setup scalping valid`);
    }

    // ── Filter 3: Zona retest terkuat M30 ────────────────────────────────
    // Gunakan selectBestZoneH1 yang sudah punya hierarki OB>FVG>S&R>Fib>UFO
    const obs30       = detectOrderBlocksH1(m30.opens, m30.highs, m30.lows, m30.closes, bias);
    const fvgs30      = detectFVGH1(m30.highs, m30.lows, bias);
    const sr30        = detectSRLevels(m30.highs, m30.lows, m30.closes);
    const snd30       = detectSnDZones(m30.highs, m30.lows, m30.closes, m30.volumes);
    const fib30       = calcFibonacci(m30.highs, m30.lows, bias);
    const ufo30       = await detectUnfilledOrdersH1(symbol, currentPrice, bias);

    const maxDist = atrH4 * 3;

    // Filter zona approaching (dalam 3x ATR H4)
    const obsFiltered = obs30.filter(ob => {
      if ((ob.touches ?? 0) > 1) return false;
      const dist = bias === 'bullish' ? currentPrice - ob.high : ob.low - currentPrice;
      return dist >= 0 && dist <= maxDist;
    });
    const fvgsFiltered = fvgs30.filter(fvg => {
      const dist = bias === 'bullish' ? currentPrice - fvg.high : fvg.low - currentPrice;
      return dist >= 0 && dist <= maxDist;
    });
    const srFiltered = sr30.filter(sr => Math.abs(currentPrice - sr.price) <= maxDist * 0.5);
    const ufoFiltered = ufo30.filter(uo => {
      const dist = bias === 'bullish' ? currentPrice - uo.high : uo.low - currentPrice;
      return dist >= 0 && dist <= maxDist;
    });

    // Pilih zona terkuat pakai hierarki selectBestZoneH1
    const bestZone30 = selectBestZoneH1(
      obsFiltered, fvgsFiltered, ufoFiltered, srFiltered, snd30, fib30, bias, currentPrice
    );

    if (!bestZone30) {
      filterResults.push(`❌ Tidak ada zona retest M30 approaching (dalam 3x ATR H4)`);
      return { status: 'no_setup', symbol, bias, currentPrice, timestamp, message: 'Tidak ada zona retest M30 yang valid', score, maxScore, filterResults };
    }
    score++;
    filterResults.push(`✅ Zona M30: ${bestZone30.zoneType} ${bestZone30.low.toFixed(4)}–${bestZone30.high.toFixed(4)}`);

    // ── Filter 4: Konfirmasi reversal — Pattern M30 ATAU RSI divergence H1 ──
    const bullPatterns = ['Double Bottom', 'Inverse H&S', 'Falling Wedge', 'Bull Flag', 'Ascending Triangle'];
    const bearPatterns = ['Double Top', 'Head & Shoulders', 'Rising Wedge', 'Bear Flag', 'Descending Triangle'];
    const validPatterns = bias === 'bullish' ? bullPatterns : bearPatterns;

    const pats30 = [
      detectBullFlag(m30.highs, m30.lows, m30.closes, m30.volumes),
      detectBearFlag(m30.highs, m30.lows, m30.closes, m30.volumes),
      detectDoubleBottom(m30.highs, m30.lows, m30.closes),
      detectDoubleTop(m30.highs, m30.lows, m30.closes),
      detectInverseHS(m30.highs, m30.lows, m30.closes),
      detectHeadAndShoulders(m30.highs, m30.lows, m30.closes),
      detectFallingWedge(m30.highs, m30.lows, m30.closes),
      detectRisingWedge(m30.highs, m30.lows, m30.closes),
      detectAscendingTriangle(m30.highs, m30.lows, m30.closes),
      detectDescendingTriangle(m30.highs, m30.lows, m30.closes),
    ].filter(p => p && validPatterns.includes(p!.name));

    // RSI divergence H1 (diperketat)
    const rsiH1 = calcRSI(h1.closes);
    const recentHighsH1 = h1.highs.slice(-8);
    const recentLowsH1 = h1.lows.slice(-8);
    let rsiDivergence = false;
    if (bias === 'bullish') {
      // Bullish divergence: harga lower low + RSI H1 < 45 (dari zona jenuh jelas)
      const priceLH = recentLowsH1[recentLowsH1.length - 1]! < recentLowsH1[recentLowsH1.length - 3]!;
      const rsiOversold = rsiH1 < 45;
      rsiDivergence = priceLH && rsiOversold;
    } else {
      // Bearish divergence: harga higher high + RSI H1 > 55 (dari zona jenuh jelas)
      const priceHH = recentHighsH1[recentHighsH1.length - 1]! > recentHighsH1[recentHighsH1.length - 3]!;
      const rsiOverbought = rsiH1 > 55;
      rsiDivergence = priceHH && rsiOverbought;
    }

    const hasConfirmation = pats30.length > 0 || rsiDivergence;
    if (!hasConfirmation) {
      filterResults.push(`❌ Tidak ada konfirmasi reversal (pattern M30 atau RSI divergence H1)`);
      return { status: 'no_setup', symbol, bias, currentPrice, timestamp,
        message: 'Tidak ada konfirmasi reversal — tunggu pattern M30 atau RSI divergence H1',
        score, maxScore, filterResults };
    }
    score++;
    const confDesc = pats30.length > 0
      ? `Pattern M30: ${pats30[0]!.name}`
      : `RSI Divergence H1 (${rsiH1.toFixed(0)})`;
    filterResults.push(`✅ Konfirmasi reversal: ${confDesc}`);

    // ── Refine zona M30 → M5 ─────────────────────────────────────────────
    const refinedZone = findBestZoneInRange(
      m5.opens, m5.highs, m5.lows, m5.closes, m5.volumes,
      bias, bestZone30.low, bestZone30.high, 'M5', bestZone30.zoneType, currentPrice
    );
    const finalZone = refinedZone ?? {
      low: bestZone30.low,
      high: bestZone30.high,
      mid: bestZone30.mid,
      entryPrice: bestZone30.entryPrice ?? bestZone30.mid,
      zoneType: bestZone30.zoneType,
      refined: false,
    };

    if (refinedZone) {
      score++;
      filterResults.push(`✅ Refine ke M5: ${refinedZone.zoneType}`);
    } else {
      filterResults.push(`ℹ️ Tidak ada zona M5 lebih presisi, pakai M30`);
    }

    // ── Entry, SL, TP ─────────────────────────────────────────────────────
    const entryPrice = finalZone.entryPrice ?? finalZone.mid;
    const swingH4H = findSwingHighs(h4.highs, 10);
    const swingH4L = findSwingLows(h4.lows, 10);
    const bufferH4 = atrH4 * 0.2;
    let stopLoss: number;
    if (bias === 'bullish') {
      const relevantLows = swingH4L.filter(l => l < entryPrice);
      const nearestLow = relevantLows.length > 0 ? Math.max(...relevantLows) : Math.min(...h4.lows.slice(-10));
      stopLoss = Math.min(nearestLow - bufferH4, entryPrice - atrH4);
    } else {
      const relevantHighs = swingH4H.filter(h => h > entryPrice);
      const nearestHigh = relevantHighs.length > 0 ? Math.min(...relevantHighs) : Math.max(...h4.highs.slice(-10));
      stopLoss = Math.max(nearestHigh + bufferH4, entryPrice + atrH4);
    }
    const risk = Math.abs(entryPrice - stopLoss);
    if (risk <= 0) return { status: 'no_setup', symbol, bias, currentPrice, timestamp, message: 'Risk tidak valid', score, maxScore, filterResults };

    const dir = bias === 'bullish' ? 1 : -1;
    const takeProfit1 = entryPrice + risk * 1.5 * dir;
    const takeProfit2 = entryPrice + risk * 3.0 * dir;

    // ── Status ────────────────────────────────────────────────────────────
    let status: ScalpingResult['status'] = 'waiting';
    const tolerance = 0.01; // ±1%
    if (bias === 'bullish') {
      if (currentPrice < stopLoss) status = 'expired';
      else if (currentPrice >= finalZone.low && currentPrice <= finalZone.high) status = 'in_zone';
      else if (currentPrice <= finalZone.high * (1 + tolerance)) status = 'in_zone';
    } else {
      if (currentPrice > stopLoss) status = 'expired';
      else if (currentPrice >= finalZone.low && currentPrice <= finalZone.high) status = 'in_zone';
      else if (currentPrice >= finalZone.low * (1 - tolerance)) status = 'in_zone';
    }

    const atrM5Pct = (calcATR(m5.highs, m5.lows, m5.closes) / currentPrice) * 100;

    const statusMsg = status === 'in_zone'
      ? `BAGUS — Harga di zona ${finalZone.zoneType}, pasang limit sekarang`
      : `WAITING — Harga belum masuk zona, setup valid`;

    return {
      status, symbol, bias, currentPrice, timestamp, score, maxScore,
      structure15M: `H4 ${bias} → M30 ${structM30.bias}`,
      choch15M: hasConfirmation,
      ob5M: { low: finalZone.low, high: finalZone.high, mid: finalZone.mid, fresh: true },
      entryPrice, stopLoss, takeProfit1, takeProfit2, rr1: 1.5, rr2: 3.0,
      atr15MPct: atrM5Pct, filterResults,
      message: trendWarning ? `${statusMsg} | ${trendWarning}` : statusMsg,
    };

  } catch (err) {
    return { status: 'error', symbol, currentPrice: 0, timestamp, message: err instanceof Error ? err.message : 'Unknown error', maxScore };
  }
}


export async function analyzeBreakoutEntry(symbol: string): Promise<BreakoutResult> {
  const timestamp = new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    hour: '2-digit', minute: '2-digit',
    day: '2-digit', month: 'long', year: 'numeric',
  }) + ' WIB';

  try {
    const [h4, h1, m30, m15, tickerRes, frRes] = await Promise.all([
      fetchKlines(symbol, '4h', 100),
      fetchKlines(symbol, '1h', 100),
      fetchKlines(symbol, '30m', 100),
      fetchKlines(symbol, '15m', 100),
      fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${symbol}`),
      fetch(`https://fapi.binance.com/fapi/v1/fundingRate?symbol=${symbol}&limit=1`),
    ]);

    const currentPrice = tickerRes.ok
      ? parseFloat((await tickerRes.json() as { price: string }).price)
      : h1.closes[h1.closes.length - 1];

    let fundingRate = 0;
    if (frRes.ok) {
      const frData = await frRes.json() as Array<{ fundingRate: string }>;
      if (frData.length > 0) fundingRate = parseFloat(frData[0].fundingRate) * 100;
    }

    const structH4 = analyzePriceActionStructure(h4.highs, h4.lows, h4.closes);
    if (structH4.bias === 'ranging')
      return { status: 'no_trend', symbol, currentPrice, timestamp, message: 'H4 ranging' };

    const bias = structH4.bias as 'bullish' | 'bearish';

    if (bias === 'bullish' && fundingRate < -0.1)
      return { status: 'skip', symbol, bias, currentPrice, timestamp, message: 'Funding rate sangat negatif', fundingRate };
    if (bias === 'bearish' && fundingRate > 0.1)
      return { status: 'skip', symbol, bias, currentPrice, timestamp, message: 'Funding rate sangat positif', fundingRate };

    // ─── Teori Dow: CHoCH H4 (hard filter — primary trend reversal) ─────────────
    const chochH4 = detectCHoCH(h4.highs, h4.lows, h4.closes, bias);
    if (chochH4) {
      return { status: 'no_trend', symbol, bias, currentPrice, timestamp,
        message: 'CHoCH H4 terbentuk — primary trend sudah berbalik, setup breakout invalid',
        chochH4Detected: true };
    }

    // ─── Teori Dow: Fase dan Volume Trend (scoring info) ─────────────────────
    const dowResult = detectDowPhase(h4.highs, h4.lows, h4.closes, h4.volumes, bias);
    const volTrend = checkVolumeTrend(h4.closes, h4.volumes, bias);

    // Distribution = hard filter untuk breakout juga
    if (dowResult.phase === 'distribution') {
      return { status: 'skip', symbol, bias, currentPrice, timestamp,
        message: `Fase Distribution H4 — ${dowResult.description}`,
        chochH4Detected: false,
        dowPhase: dowResult.phase, dowPhaseDesc: dowResult.description };
    }

    // Deteksi breakout di H1 dan M30 — ambil yang paling kuat (volume ratio tertinggi)
    const breakoutH1 = detectBreakoutH1(h1.opens, h1.highs, h1.lows, h1.closes, h1.volumes, bias);
    const breakoutM30 = detectBreakoutH1(m30.opens, m30.highs, m30.lows, m30.closes, m30.volumes, bias);

    let breakout = breakoutH1;
    let breakoutTf = 'H1';
    if (!breakoutH1 && breakoutM30) {
      breakout = breakoutM30;
      breakoutTf = 'M30';
    } else if (breakoutH1 && breakoutM30 && breakoutM30.volumeRatio > breakoutH1.volumeRatio) {
      breakout = breakoutM30;
      breakoutTf = 'M30';
    }

    if (!breakout)
      return { status: 'no_breakout', symbol, bias, currentPrice, timestamp, message: 'Tidak ada breakout valid di H1/M30' };

    const atrH1 = calcATR(h1.highs, h1.lows, h1.closes);
    const atrH2 = calcATR(m30.highs, m30.lows, m30.closes); // M30 ≈ H2
    const atr15m = calcATR(m15.highs, m15.lows, m15.closes);

    // Gunakan data TF yang terdeteksi breakout untuk findRetestZone
    const brkData = breakoutTf === 'M30' ? m30 : h1;
    const retestZone = findRetestZone(
      brkData.highs, brkData.lows, brkData.closes, brkData.opens, brkData.volumes,
      m15.highs, m15.lows, m15.closes,
      breakout, currentPrice, atrH1, bias, atrH2
    );

    if (!retestZone)
      return { status: 'no_zone', symbol, bias, currentPrice, timestamp,
        message: 'Tidak ada zona retest valid',
        breakoutType: breakout.type, brokenLevel: breakout.brokenLevel, volumeRatio: breakout.volumeRatio };

    const inZone = retestZone.isReached;

    // ─── OPSI A: Cek pattern di H4/H1/M30 yang searah (confidence boost) ─────
    const bullishContinuation = ['Bull Flag', 'Ascending Triangle', 'Pennant', 'Symmetrical Triangle'];
    const bullishReversal = ['Double Bottom', 'Inverse H&S', 'Falling Wedge'];
    const bearishContinuation = ['Bear Flag', 'Descending Triangle', 'Pennant', 'Symmetrical Triangle'];
    const bearishReversal = ['Double Top', 'Head & Shoulders', 'Rising Wedge'];
    const validBullish = [...bullishContinuation, ...bullishReversal];
    const validBearish = [...bearishContinuation, ...bearishReversal];

    const detectAllPatterns = (kline: KlineData): PatternResult[] => {
      const { highs: h, lows: l, closes: c, volumes: v } = kline;
      const results: PatternResult[] = [];
      const checks = [
        detectBullFlag(h, l, c, v), detectBearFlag(h, l, c, v),
        detectAscendingTriangle(h, l, c), detectDescendingTriangle(h, l, c),
        detectSymmetricalTriangle(h, l, c), detectPennant(h, l, c, v),
        detectDoubleTop(h, l, c), detectDoubleBottom(h, l, c),
        detectHeadAndShoulders(h, l, c), detectInverseHS(h, l, c),
        detectRisingWedge(h, l, c), detectFallingWedge(h, l, c),
      ];
      for (const r of checks) { if (r) results.push(r); }
      return results;
    };

    // Cek pattern di H4, H1, M30
    const validList = bias === 'bullish' ? validBullish : validBearish;
    const h4Patterns = detectAllPatterns(h4).filter(p => validList.includes(p.name));
    const h1Patterns = detectAllPatterns(h1).filter(p => validList.includes(p.name));
    const m30Patterns = detectAllPatterns(m30).filter(p => validList.includes(p.name));
    const allConfirmingPatterns = [
      ...h4Patterns.map(p => `H4: ${p.name}`),
      ...h1Patterns.map(p => `H1: ${p.name}`),
      ...m30Patterns.map(p => `M30: ${p.name}`),
    ];
    const patternCount = allConfirmingPatterns.length;
    const patternConfidence: 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE' =
      patternCount >= 2 ? 'HIGH' : patternCount === 1 ? 'MEDIUM' : 'LOW';

    // ─── OPSI B: Cek pattern 15M untuk konfirmasi zona retest ─────────────────
    const bullishReversalShort = ['Double Bottom', 'Inverse H&S', 'Falling Wedge', 'Bull Flag'];
    const bearishReversalShort = ['Double Top', 'Head & Shoulders', 'Rising Wedge', 'Bear Flag'];
    const validZoneList = bias === 'bullish' ? bullishReversalShort : bearishReversalShort;

    let retestConfirmed = false;
    let zonePatternConfirmed = false;

    if (inZone) {
      // Rejection candle di 15M
      const last = m15.closes.length - 1;
      for (let i = last; i >= Math.max(0, last - 2); i--) {
        const body = Math.abs(m15.closes[i] - m15.opens[i]);
        const wick = bias === 'bullish'
          ? Math.min(m15.opens[i], m15.closes[i]) - m15.lows[i]
          : m15.highs[i] - Math.max(m15.opens[i], m15.closes[i]);
        if (body > 0 && wick > body * 1.5) { retestConfirmed = true; break; }
      }

      // Pattern konfirmasi di 15M
      const m15Patterns = detectAllPatterns(m15).filter(p => validZoneList.includes(p.name));
      zonePatternConfirmed = m15Patterns.length > 0;
    }

    // ─── HARD FILTER 1: CHoCH 15M ───────────────────────────────────────────────
    const choch15MResult = detectCHoCH15M(m15.highs, m15.lows, m15.closes, bias);
    if (!choch15MResult.detected) {
      return {
        status: 'no_setup',
        symbol, bias, currentPrice, timestamp,
        message: 'CHoCH 15M belum terkonfirmasi — tunggu struktur 15M berbalik',
        breakoutType: breakout.type,
        brokenLevel: breakout.brokenLevel,
        volumeRatio: breakout.volumeRatio,
        retestZone,
        choch15M: false,
        choch15MDesc: choch15MResult.description,
      };
    }

    // ─── HARD FILTER 2: Rejection candle 15M ─────────────────────────────────
    const refinedForRejection = {
      low: retestZone.low ?? retestZone.price - atrH1 * 0.3,
      high: retestZone.high ?? retestZone.price + atrH1 * 0.3,
      mid: retestZone.price,
      entryPrice: retestZone.price,
      zoneType: retestZone.type,
      refined: false,
    };
    const rejection15MResult = checkRejection15M(
      refinedForRejection, m15.opens, m15.highs, m15.lows, m15.closes, bias, m15.volumes
    );
    if (!rejection15MResult.confirmed) {
      return {
        status: 'no_setup',
        symbol, bias, currentPrice, timestamp,
        message: 'Belum ada rejection candle 15M di zona retest',
        breakoutType: breakout.type,
        brokenLevel: breakout.brokenLevel,
        volumeRatio: breakout.volumeRatio,
        retestZone,
        choch15M: true,
        choch15MDesc: choch15MResult.description,
        rejection15M: false,
        rejection15MCandle: rejection15MResult.candleType,
      };
    }

    // ─── HARD FILTER 3: Pattern konfirmasi ───────────────────────────────────
    const allBreakoutPatterns = [...allConfirmingPatterns];
    const hasPattern = allBreakoutPatterns.length > 0;
    if (!hasPattern) {
      return {
        status: 'no_setup',
        symbol, bias, currentPrice, timestamp,
        message: 'Tidak ada pattern konfirmasi searah bias',
        breakoutType: breakout.type,
        brokenLevel: breakout.brokenLevel,
        volumeRatio: breakout.volumeRatio,
        retestZone,
        choch15M: true,
        choch15MDesc: choch15MResult.description,
        rejection15M: true,
        rejection15MCandle: rejection15MResult.candleType,
        patternConfirmed: false,
      };
    }

    // Semua filter lolos — lanjut ke status
    const isReady = inZone && retestConfirmed && (zonePatternConfirmed || patternConfidence === 'HIGH');
    const status = isReady ? 'ready' : inZone ? 'in_zone' : 'approaching';

    const entryPrice = retestZone.price;
    const dir = bias === 'bullish' ? 1 : -1;

    // SL berdasarkan swing high/low H1 terdekat (20 candle lookback)
    const m4SwingHighs = findSwingHighs(h1.highs, 20);
    const m4SwingLows = findSwingLows(h1.lows, 20);
    const m4Buffer = atrH1 * 0.2;

    let stopLoss: number;
    if (bias === 'bullish') {
      const relevantLows = m4SwingLows.filter(l => l < entryPrice);
      const nearestSwingLow = relevantLows.length > 0
        ? Math.max(...relevantLows)
        : Math.min(...h1.lows.slice(-20));
      const rawSl = nearestSwingLow - m4Buffer;
      const minSl = entryPrice - atrH2;
      stopLoss = Math.min(rawSl, minSl);
    } else {
      const relevantHighs = m4SwingHighs.filter(h => h > entryPrice);
      const nearestSwingHigh = relevantHighs.length > 0
        ? Math.min(...relevantHighs)
        : Math.max(...h1.highs.slice(-20));
      const rawSl = nearestSwingHigh + m4Buffer;
      const minSl = entryPrice + atrH2;
      stopLoss = Math.max(rawSl, minSl);
    }
    const risk = Math.abs(entryPrice - stopLoss);
    const takeProfit1 = entryPrice + risk * 1.5 * dir;
    const takeProfit2 = entryPrice + risk * 3.0 * dir;
    const takeProfit3 = breakout.volumeRatio >= 2.0 ? entryPrice + risk * 5.0 * dir : undefined;

    const reasonParts = [`${retestZone.type} (Tier ${retestZone.tier}) — ${retestZone.reason}`];
    if (allConfirmingPatterns.length > 0)
      reasonParts.push(`Pattern: ${allConfirmingPatterns.join(', ')}`);

    return {
      status,
      symbol, bias, currentPrice, timestamp,
      breakoutType: breakout.type, brokenLevel: breakout.brokenLevel, volumeRatio: breakout.volumeRatio,
      retestZone, retestConfirmed,
      patternConfidence,
      confirmingPatterns: allConfirmingPatterns,
      choch15M: true,
      choch15MDesc: choch15MResult.description,
      rejection15M: true,
      rejection15MCandle: rejection15MResult.candleType,
      patternConfirmed: true,
      patternName: allBreakoutPatterns[0],
      chochH4Detected: false,
      dowPhase: dowResult.phase,
      dowPhaseDesc: dowResult.description,
      volumeTrendValid: volTrend.valid,
      volumeTrendDesc: volTrend.description,
      entryPrice, stopLoss, takeProfit1, takeProfit2, takeProfit3,
      fundingRate, setupExpiryHours: 8,
      reason: reasonParts.join(' | '),
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return { status: 'error', symbol, currentPrice: 0, timestamp, message };
  }
}

// ─── Menu 5: Chart Pattern Detection ─────────────────────────────────────────

export interface PatternResult {
  name: string;
  category: 'continuation' | 'reversal';
  direction: 'bullish' | 'bearish';
  confidence: 'high' | 'medium' | 'low';
  description: string;
}

export interface TFPatterns {
  tf: string;
  patterns: PatternResult[];
}

function detectBullFlag(highs: number[], lows: number[], closes: number[], volumes: number[]): PatternResult | null {
  const n = closes.length;
  if (n < 20) return null;
  const poleStart = n - 20, poleEnd = n - 10;
  const poleMove = (closes[poleEnd] - closes[poleStart]) / closes[poleStart] * 100;
  if (poleMove < 3) return null;
  const flagHighs = highs.slice(n - 8), flagLows = lows.slice(n - 8);
  const flagRange = (Math.max(...flagHighs) - Math.min(...flagLows)) / closes[n - 8] * 100;
  if (flagRange > 4) return null;
  const flagDrift = (closes[n - 1] - closes[n - 8]) / closes[n - 8] * 100;
  if (flagDrift > 1.5) return null;
  const poleVol = volumes.slice(poleStart, poleEnd).reduce((a, b) => a + b, 0) / (poleEnd - poleStart);
  const flagVol = volumes.slice(n - 8).reduce((a, b) => a + b, 0) / 8;
  if (flagVol >= poleVol) return null;
  return { name: 'Bull Flag', category: 'continuation', direction: 'bullish', confidence: poleMove > 6 ? 'high' : 'medium', description: `Pole +${poleMove.toFixed(1)}%, flag konsolidasi ${flagRange.toFixed(1)}%` };
}

function detectBearFlag(highs: number[], lows: number[], closes: number[], volumes: number[]): PatternResult | null {
  const n = closes.length;
  if (n < 20) return null;
  const poleStart = n - 20, poleEnd = n - 10;
  const poleMove = (closes[poleStart] - closes[poleEnd]) / closes[poleStart] * 100;
  if (poleMove < 3) return null;
  const flagHighs = highs.slice(n - 8), flagLows = lows.slice(n - 8);
  const flagRange = (Math.max(...flagHighs) - Math.min(...flagLows)) / closes[n - 8] * 100;
  if (flagRange > 4) return null;
  const flagDrift = (closes[n - 1] - closes[n - 8]) / closes[n - 8] * 100;
  if (flagDrift < -1.5) return null;
  const poleVol = volumes.slice(poleStart, poleEnd).reduce((a, b) => a + b, 0) / (poleEnd - poleStart);
  const flagVol = volumes.slice(n - 8).reduce((a, b) => a + b, 0) / 8;
  if (flagVol >= poleVol) return null;
  return { name: 'Bear Flag', category: 'continuation', direction: 'bearish', confidence: poleMove > 6 ? 'high' : 'medium', description: `Pole -${poleMove.toFixed(1)}%, flag konsolidasi ${flagRange.toFixed(1)}%` };
}

function detectAscendingTriangle(highs: number[], lows: number[], closes: number[]): PatternResult | null {
  const n = closes.length;
  if (n < 15) return null;
  const swingH = findSwingHighs(highs.slice(n - 15), 3);
  if (swingH.length < 2) return null;
  const maxH = Math.max(...swingH), minH = Math.min(...swingH);
  if ((maxH - minH) / minH * 100 > 1.5) return null;
  const swingL = findSwingLows(lows.slice(n - 15), 3);
  if (swingL.length < 2) return null;
  if (swingL[swingL.length - 1] <= swingL[0]) return null;
  return { name: 'Ascending Triangle', category: 'continuation', direction: 'bullish', confidence: 'medium', description: `Resistance flat di ${maxH.toFixed(4)}, support naik` };
}

function detectDescendingTriangle(highs: number[], lows: number[], closes: number[]): PatternResult | null {
  const n = closes.length;
  if (n < 15) return null;
  const swingL = findSwingLows(lows.slice(n - 15), 3);
  if (swingL.length < 2) return null;
  const maxL = Math.max(...swingL), minL = Math.min(...swingL);
  if ((maxL - minL) / minL * 100 > 1.5) return null;
  const swingH = findSwingHighs(highs.slice(n - 15), 3);
  if (swingH.length < 2) return null;
  if (swingH[swingH.length - 1] >= swingH[0]) return null;
  return { name: 'Descending Triangle', category: 'continuation', direction: 'bearish', confidence: 'medium', description: `Support flat di ${minL.toFixed(4)}, resistance turun` };
}

function detectSymmetricalTriangle(highs: number[], lows: number[], closes: number[]): PatternResult | null {
  const n = closes.length;
  if (n < 15) return null;
  const swingH = findSwingHighs(highs.slice(n - 15), 3);
  const swingL = findSwingLows(lows.slice(n - 15), 3);
  if (swingH.length < 2 || swingL.length < 2) return null;
  if (swingH[swingH.length - 1] >= swingH[0]) return null;
  if (swingL[swingL.length - 1] <= swingL[0]) return null;
  const bias = closes[n - 1] > closes[n - 8] ? 'bullish' : 'bearish';
  return { name: 'Symmetrical Triangle', category: 'continuation', direction: bias as 'bullish' | 'bearish', confidence: 'low', description: `HH turun + HL naik, bias ${bias}` };
}

function detectPennant(highs: number[], lows: number[], closes: number[], volumes: number[]): PatternResult | null {
  const n = closes.length;
  if (n < 20) return null;
  const poleStart = n - 20, poleEnd = n - 12;
  const poleMove = Math.abs((closes[poleEnd] - closes[poleStart]) / closes[poleStart] * 100);
  if (poleMove < 4) return null;
  const dir = closes[poleEnd] > closes[poleStart] ? 'bullish' : 'bearish';
  const swH = findSwingHighs(highs.slice(n - 10), 2);
  const swL = findSwingLows(lows.slice(n - 10), 2);
  if (swH.length < 2 || swL.length < 2) return null;
  if (swH[swH.length - 1] >= swH[0]) return null;
  if (swL[swL.length - 1] <= swL[0]) return null;
  const poleVol = volumes.slice(poleStart, poleEnd).reduce((a, b) => a + b, 0) / (poleEnd - poleStart);
  const pennantVol = volumes.slice(n - 10).reduce((a, b) => a + b, 0) / 10;
  if (pennantVol >= poleVol) return null;
  return { name: 'Pennant', category: 'continuation', direction: dir as 'bullish' | 'bearish', confidence: 'medium', description: `Pole ${dir === 'bullish' ? '+' : '-'}${poleMove.toFixed(1)}%, pennant konsolidasi volume turun` };
}

function detectDoubleTop(highs: number[], lows: number[], closes: number[]): PatternResult | null {
  const n = closes.length;
  if (n < 30) return null;
  const swingH = findSwingHighs(highs.slice(n - 30), 5);
  if (swingH.length < 2) return null;
  const last = swingH[swingH.length - 1], prev = swingH[swingH.length - 2];
  const diff = Math.abs(last - prev) / prev * 100;
  if (diff > 1.5) return null;
  const neckline = Math.min(...lows.slice(n - 30));
  if (closes[n - 1] < neckline * 1.005) {
    return { name: 'Double Top', category: 'reversal', direction: 'bearish', confidence: diff < 0.8 ? 'high' : 'medium', description: `Dua puncak di ~${((last + prev) / 2).toFixed(4)}, neckline ${neckline.toFixed(4)}` };
  }
  return null;
}

function detectDoubleBottom(highs: number[], lows: number[], closes: number[]): PatternResult | null {
  const n = closes.length;
  if (n < 30) return null;
  const swingL = findSwingLows(lows.slice(n - 30), 5);
  if (swingL.length < 2) return null;
  const last = swingL[swingL.length - 1], prev = swingL[swingL.length - 2];
  const diff = Math.abs(last - prev) / prev * 100;
  if (diff > 1.5) return null;
  const neckline = Math.max(...highs.slice(n - 30));
  if (closes[n - 1] > neckline * 0.995) {
    return { name: 'Double Bottom', category: 'reversal', direction: 'bullish', confidence: diff < 0.8 ? 'high' : 'medium', description: `Dua lembah di ~${((last + prev) / 2).toFixed(4)}, neckline ${neckline.toFixed(4)}` };
  }
  return null;
}

function detectHeadAndShoulders(highs: number[], lows: number[], closes: number[]): PatternResult | null {
  const n = closes.length;
  if (n < 40) return null;
  const swingH = findSwingHighs(highs.slice(n - 40), 5);
  if (swingH.length < 3) return null;
  const [ls, head, rs] = swingH.slice(-3);
  if (head <= ls || head <= rs) return null;
  const shoulderDiff = Math.abs(ls - rs) / ls * 100;
  if (shoulderDiff > 3) return null;
  if (head < Math.max(ls, rs) * 1.01) return null;
  return { name: 'Head & Shoulders', category: 'reversal', direction: 'bearish', confidence: shoulderDiff < 1.5 ? 'high' : 'medium', description: `LS ${ls.toFixed(4)}, Head ${head.toFixed(4)}, RS ${rs.toFixed(4)}` };
}

function detectInverseHS(highs: number[], lows: number[], closes: number[]): PatternResult | null {
  const n = closes.length;
  if (n < 40) return null;
  const swingL = findSwingLows(lows.slice(n - 40), 5);
  if (swingL.length < 3) return null;
  const [ls, head, rs] = swingL.slice(-3);
  if (head >= ls || head >= rs) return null;
  const shoulderDiff = Math.abs(ls - rs) / ls * 100;
  if (shoulderDiff > 3) return null;
  if (head > Math.min(ls, rs) * 0.99) return null;
  return { name: 'Inverse H&S', category: 'reversal', direction: 'bullish', confidence: shoulderDiff < 1.5 ? 'high' : 'medium', description: `LS ${ls.toFixed(4)}, Head ${head.toFixed(4)}, RS ${rs.toFixed(4)}` };
}

function detectRisingWedge(highs: number[], lows: number[], closes: number[]): PatternResult | null {
  const n = closes.length;
  if (n < 15) return null;
  const swingH = findSwingHighs(highs.slice(n - 15), 3);
  const swingL = findSwingLows(lows.slice(n - 15), 3);
  if (swingH.length < 2 || swingL.length < 2) return null;
  if (swingH[swingH.length - 1] <= swingH[0]) return null;
  if (swingL[swingL.length - 1] <= swingL[0]) return null;
  const slopeH = (swingH[swingH.length - 1] - swingH[0]) / swingH[0];
  const slopeL = (swingL[swingL.length - 1] - swingL[0]) / swingL[0];
  if (slopeL <= slopeH) return null;
  return { name: 'Rising Wedge', category: 'reversal', direction: 'bearish', confidence: 'medium', description: `Support naik lebih cepat dari resistance — sinyal bearish reversal` };
}

function detectFallingWedge(highs: number[], lows: number[], closes: number[]): PatternResult | null {
  const n = closes.length;
  if (n < 15) return null;
  const swingH = findSwingHighs(highs.slice(n - 15), 3);
  const swingL = findSwingLows(lows.slice(n - 15), 3);
  if (swingH.length < 2 || swingL.length < 2) return null;
  if (swingH[swingH.length - 1] >= swingH[0]) return null;
  if (swingL[swingL.length - 1] >= swingL[0]) return null;
  const slopeH = (swingH[0] - swingH[swingH.length - 1]) / swingH[0];
  const slopeL = (swingL[0] - swingL[swingL.length - 1]) / swingL[0];
  if (slopeL <= slopeH) return null;
  return { name: 'Falling Wedge', category: 'reversal', direction: 'bullish', confidence: 'medium', description: `Resistance turun lebih cepat dari support — sinyal bullish reversal` };
}

export async function analyzeChartPatterns(symbol: string): Promise<{ symbol: string; timestamp: string; timeframes: TFPatterns[] }> {
  const timestamp = new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit',
    day: '2-digit', month: 'long', year: 'numeric',
  }) + ' WIB';

  const [h4, h1, m30, m15, m5] = await Promise.all([
    fetchKlines(symbol, '4h', 100),
    fetchKlines(symbol, '1h', 100),
    fetchKlines(symbol, '30m', 100),
    fetchKlines(symbol, '15m', 100),
    fetchKlines(symbol, '5m', 100),
  ]);

  const detect = (kline: KlineData): PatternResult[] => {
    const { highs: h, lows: l, closes: c, volumes: v } = kline;
    const results: PatternResult[] = [];
    const checks = [
      detectBullFlag(h, l, c, v),
      detectBearFlag(h, l, c, v),
      detectAscendingTriangle(h, l, c),
      detectDescendingTriangle(h, l, c),
      detectSymmetricalTriangle(h, l, c),
      detectPennant(h, l, c, v),
      detectDoubleTop(h, l, c),
      detectDoubleBottom(h, l, c),
      detectHeadAndShoulders(h, l, c),
      detectInverseHS(h, l, c),
      detectRisingWedge(h, l, c),
      detectFallingWedge(h, l, c),
    ];
    for (const r of checks) { if (r) results.push(r); }
    return results;
  };

  return {
    symbol,
    timestamp,
    timeframes: [
      { tf: 'H4', patterns: detect(h4) },
      { tf: 'H1', patterns: detect(h1) },
      { tf: 'M30', patterns: detect(m30) },
      { tf: 'M15', patterns: detect(m15) },
      { tf: 'M5', patterns: detect(m5) },
    ],
  };
}
// ─── Menu 6: Backtesting Engine ───────────────────────────────────────────────

export interface BacktestTrade {
  menu: 'sniper' | 'breakout' | 'scalping';
  entryTime: number;
  entryPrice: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  bias: 'bullish' | 'bearish';
  result: 'TP1' | 'TP2' | 'SL' | 'EXPIRED';
  exitPrice: number;
  rr: number; // R:R terealisasi
  // Kondisi saat sinyal
  hasChoch15M: boolean;
  hasRejection15M: boolean;
  hasPattern: boolean;
  patternConfidence: string;
  zoneTier: number;
  breakoutType?: string;
  volumeRatio?: number;
  hour: number; // jam WIB saat sinyal
}

export interface BacktestAnalysis {
  totalTrades: number;
  wins: number;
  losses: number;
  winRate: number;
  avgRR: number;
  // Breakdown kondisi
  breakdown: {
    withChoch15M: { trades: number; wins: number; winRate: number };
    withoutChoch15M: { trades: number; wins: number; winRate: number };
    withRejection15M: { trades: number; wins: number; winRate: number };
    withoutRejection15M: { trades: number; wins: number; winRate: number };
    withPattern: { trades: number; wins: number; winRate: number };
    withoutPattern: { trades: number; wins: number; winRate: number };
    tier1to2: { trades: number; wins: number; winRate: number };
    tier3plus: { trades: number; wins: number; winRate: number };
    londonNY: { trades: number; wins: number; winRate: number };
    asian: { trades: number; wins: number; winRate: number };
    highVolume: { trades: number; wins: number; winRate: number };
    lowVolume: { trades: number; wins: number; winRate: number };
  };
  // Penyebab lose
  lossCauses: Array<{ cause: string; count: number; percentage: number }>;
  // Rekomendasi (hanya jika winRate < 75%)
  recommendations: string[];
}

export interface BacktestResult {
  symbol: string;
  period: string;
  totalCandles: number;
  sniperResult?: BacktestAnalysis & { trades: BacktestTrade[] };
  breakoutResult?: BacktestAnalysis & { trades: BacktestTrade[] };
  scalpingResult?: BacktestAnalysis & { trades: BacktestTrade[] };
  comparison?: {
    better: 'sniper' | 'breakout' | 'equal';
    sniperWinRate: number;
    breakoutWinRate: number;
    mostImpactfulFilter: string;
  };
  timestamp: string;
}

function getWIBHour(timestamp: number): number {
  const date = new Date(timestamp);
  return (date.getUTCHours() + 7) % 24;
}

function isLondonNY(hour: number): boolean {
  return (hour >= 14 && hour <= 23);
}

function analyzeWinRate(wins: number, total: number): number {
  if (total === 0) return 0;
  return Math.round((wins / total) * 100 * 10) / 10;
}

function buildAnalysis(trades: BacktestTrade[]): BacktestAnalysis {
  const total = trades.length;
  const wins = trades.filter(t => t.result === 'TP1' || t.result === 'TP2').length;
  const winRate = analyzeWinRate(wins, total);
  const avgRR = total > 0
    ? Math.round(trades.reduce((sum, t) => sum + t.rr, 0) / total * 100) / 100
    : 0;

  // Breakdown
  const groups = {
    withChoch15M: trades.filter(t => t.hasChoch15M),
    withoutChoch15M: trades.filter(t => !t.hasChoch15M),
    withRejection15M: trades.filter(t => t.hasRejection15M),
    withoutRejection15M: trades.filter(t => !t.hasRejection15M),
    withPattern: trades.filter(t => t.hasPattern),
    withoutPattern: trades.filter(t => !t.hasPattern),
    tier1to2: trades.filter(t => t.zoneTier <= 2),
    tier3plus: trades.filter(t => t.zoneTier > 2),
    londonNY: trades.filter(t => isLondonNY(t.hour)),
    asian: trades.filter(t => !isLondonNY(t.hour)),
    highVolume: trades.filter(t => t.volumeRatio !== undefined && t.volumeRatio >= 2),
    lowVolume: trades.filter(t => t.volumeRatio !== undefined && t.volumeRatio < 2),
  };

  const breakdown: BacktestAnalysis['breakdown'] = {} as BacktestAnalysis['breakdown'];
  for (const [key, group] of Object.entries(groups)) {
    const w = group.filter(t => t.result === 'TP1' || t.result === 'TP2').length;
    (breakdown as any)[key] = {
      trades: group.length,
      wins: w,
      winRate: analyzeWinRate(w, group.length),
    };
  }

  // Analisa penyebab lose
  const loseTrades = trades.filter(t => t.result === 'SL');
  const causeCounts: Record<string, number> = {};

  for (const t of loseTrades) {
    if (!t.hasChoch15M) {
      causeCounts['CHoCH 15M tidak terkonfirmasi'] = (causeCounts['CHoCH 15M tidak terkonfirmasi'] ?? 0) + 1;
    }
    if (!t.hasRejection15M) {
      causeCounts['Tidak ada rejection candle 15M'] = (causeCounts['Tidak ada rejection candle 15M'] ?? 0) + 1;
    }
    if (!t.hasPattern) {
      causeCounts['Tidak ada pattern konfirmasi'] = (causeCounts['Tidak ada pattern konfirmasi'] ?? 0) + 1;
    }
    if (t.zoneTier > 2) {
      causeCounts['Entry di zona Tier 3+ (kualitas rendah)'] = (causeCounts['Entry di zona Tier 3+ (kualitas rendah)'] ?? 0) + 1;
    }

    if (t.volumeRatio !== undefined && t.volumeRatio < 2) {
      causeCounts['Volume breakout rendah (< 2x)'] = (causeCounts['Volume breakout rendah (< 2x)'] ?? 0) + 1;
    }
  }

  const lossCauses = Object.entries(causeCounts)
    .map(([cause, count]) => ({
      cause,
      count,
      percentage: Math.round((count / Math.max(loseTrades.length, 1)) * 100),
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  // Rekomendasi hanya jika winRate < 75%
  const recommendations: string[] = [];
  if (winRate < 75) {
    const bd = breakdown;
    if (bd.withChoch15M.winRate > bd.withoutChoch15M.winRate + 10 && bd.withoutChoch15M.trades > 3) {
      recommendations.push(
        `Win rate dengan CHoCH 15M (${bd.withChoch15M.winRate}%) jauh lebih tinggi dari tanpa CHoCH (${bd.withoutChoch15M.winRate}%) → Hanya entry jika CHoCH 15M sudah terkonfirmasi`
      );
    }
    if (bd.withRejection15M.winRate > bd.withoutRejection15M.winRate + 10 && bd.withoutRejection15M.trades > 3) {
      recommendations.push(
        `Win rate dengan rejection 15M (${bd.withRejection15M.winRate}%) jauh lebih tinggi → Tunggu candle rejection sebelum pasang limit order`
      );
    }
    if (bd.withPattern.winRate > bd.withoutPattern.winRate + 10 && bd.withoutPattern.trades > 3) {
      recommendations.push(
        `Win rate dengan pattern konfirmasi (${bd.withPattern.winRate}%) lebih tinggi → Prioritaskan sinyal yang ada pattern searah`
      );
    }
    if (bd.tier1to2.winRate > bd.tier3plus.winRate + 10 && bd.tier3plus.trades > 3) {
      recommendations.push(
        `Win rate zona Tier 1-2 (${bd.tier1to2.winRate}%) jauh lebih baik dari Tier 3+ (${bd.tier3plus.winRate}%) → Fokus hanya di zona Tier 1-2`
      );
    }
    if (bd.londonNY.winRate > bd.asian.winRate + 10 && bd.asian.trades > 3) {
      recommendations.push(
        `Breakdown sesi: London/NY ${bd.londonNY.winRate}% vs Asian ${bd.asian.winRate}%`
      );
    }
    if (bd.highVolume.winRate > bd.lowVolume.winRate + 10 && bd.lowVolume.trades > 3) {
      recommendations.push(
        `Win rate volume breakout tinggi (${bd.highVolume.winRate}%) jauh lebih baik → Skip sinyal dengan volume ratio < 2x`
      );
    }
    if (recommendations.length === 0) {
      recommendations.push('Tingkatkan ukuran sampel — perlu lebih banyak trade untuk analisa yang akurat');
    }
  }

  return { totalTrades: total, wins, losses: total - wins, winRate, avgRR, breakdown, lossCauses, recommendations };
}

function simulateTrade(
  entryPrice: number,
  stopLoss: number,
  takeProfit1: number,
  takeProfit2: number,
  bias: 'bullish' | 'bearish',
  futureHighs: number[],
  futureLows: number[],
  maxCandles: number = 48 // max 48 candle H1 = 2 hari
): { result: 'TP1' | 'TP2' | 'SL' | 'EXPIRED'; exitPrice: number; rr: number } {
  const risk = Math.abs(entryPrice - stopLoss);
  const dir = bias === 'bullish' ? 1 : -1;
  const limit = Math.min(futureHighs.length, maxCandles);

  for (let i = 0; i < limit; i++) {
    const high = futureHighs[i];
    const low = futureLows[i];

    if (bias === 'bullish') {
      if (low <= stopLoss) return { result: 'SL', exitPrice: stopLoss, rr: -1 };
      if (high >= takeProfit2 && takeProfit2 > 0) return { result: 'TP2', exitPrice: takeProfit2, rr: Math.round(((takeProfit2 - entryPrice) / risk) * 10) / 10 };
      if (high >= takeProfit1) return { result: 'TP1', exitPrice: takeProfit1, rr: Math.round(((takeProfit1 - entryPrice) / risk) * 10) / 10 };
    } else {
      if (high >= stopLoss) return { result: 'SL', exitPrice: stopLoss, rr: -1 };
      if (low <= takeProfit2 && takeProfit2 > 0) return { result: 'TP2', exitPrice: takeProfit2, rr: Math.round(((entryPrice - takeProfit2) / risk) * 10) / 10 };
      if (low <= takeProfit1) return { result: 'TP1', exitPrice: takeProfit1, rr: Math.round(((entryPrice - takeProfit1) / risk) * 10) / 10 };
    }
  }
  return { result: 'EXPIRED', exitPrice: futureHighs[limit - 1] ?? entryPrice, rr: 0 };
}

function getPeriodLimit(period: '1m' | '3m' | '6m' | '1y' | 'all', allH1Candles?: number): number {
  // H1 candles needed
  const map: Record<string, number> = { '1m': 720, '3m': 2160, '6m': 4320, '1y': 8640 };
  if (period === 'all' && allH1Candles) return allH1Candles;
  return map[period] ?? 8640;
}

export async function runBacktest(
  symbol: string,
  period: '1m' | '3m' | '6m' | '1y' | 'all',
  menu: 'sniper' | 'breakout' | 'scalping' | 'both',
  allH1Candles?: number
): Promise<BacktestResult> {
  const timestamp = new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit',
    day: '2-digit', month: 'long', year: 'numeric',
  }) + ' WIB';

  const limit = getPeriodLimit(period, allH1Candles);
  const periodLabel = period === 'all'
    ? `Sejak Listing — maks 3 tahun (${Math.round(limit / 720)} bulan)`
    : { '1m': '1 Bulan', '3m': '3 Bulan', '6m': '6 Bulan', '1y': '1 Tahun' }[period]!;

  // Fetch data historis H4 dan H1 dalam batch (max 1500 per request)
  async function fetchHistorical(interval: string, totalLimit: number): Promise<KlineData> {
    const batchSize = 1000;
    const batches = Math.ceil(totalLimit / batchSize);
    const allHighs: number[] = [];
    const allLows: number[] = [];
    const allCloses: number[] = [];
    const allOpens: number[] = [];
    const allVolumes: number[] = [];
    const allTimes: number[] = [];

    // Fetch dari yang paling lama dulu
    let endTime: number | undefined;
    for (let b = batches - 1; b >= 0; b--) {
      const url = endTime
        ? `https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${batchSize}&endTime=${endTime}`
        : `https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${batchSize}`;
      const res = await fetch(url);
      if (!res.ok) break;
      const data: number[][] = await res.json();
      if (data.length === 0) break;
      endTime = data[0][0] - 1;

      // Prepend ke array (dari lama ke baru)
      for (let i = data.length - 1; i >= 0; i--) {
        allTimes.unshift(data[i][0]);
        allOpens.unshift(parseFloat(String(data[i][1])));
        allHighs.unshift(parseFloat(String(data[i][2])));
        allLows.unshift(parseFloat(String(data[i][3])));
        allCloses.unshift(parseFloat(String(data[i][4])));
        allVolumes.unshift(parseFloat(String(data[i][5])));
      }
    }

    return {
      highs: allHighs.slice(-totalLimit),
      lows: allLows.slice(-totalLimit),
      closes: allCloses.slice(-totalLimit),
      opens: allOpens.slice(-totalLimit),
      volumes: allVolumes.slice(-totalLimit),
      times: allTimes.slice(-totalLimit),
    };
  }

  // Fetch semua data yang diperlukan
  const [h4Data, h1Data, m15Data] = await Promise.all([
    fetchHistorical('4h', Math.ceil(limit / 4)),
    fetchHistorical('1h', limit),
    fetchHistorical('15m', limit * 4),
  ]);

  const result: BacktestResult = {
    symbol,
    period: periodLabel,
    totalCandles: h1Data.closes.length,
    timestamp,
  };

  // ─── BACKTEST MENU 2 (SNIPER) ─────────────────────────────────────────────
  if (menu === 'sniper' || menu === 'both') {
    const sniperTrades: BacktestTrade[] = [];
    const MIN_CANDLES = 50;
    const STEP = 4; // cek setiap 4 jam (tidak perlu tiap candle)

    for (let i = MIN_CANDLES; i < h1Data.closes.length - 50; i += STEP) {
      // Data sampai candle i
      const h4Slice = {
        highs: h4Data.highs.slice(0, Math.floor(i / 4)),
        lows: h4Data.lows.slice(0, Math.floor(i / 4)),
        closes: h4Data.closes.slice(0, Math.floor(i / 4)),
        opens: h4Data.opens.slice(0, Math.floor(i / 4)),
        volumes: h4Data.volumes.slice(0, Math.floor(i / 4)),
      };
      const h1Slice = {
        highs: h1Data.highs.slice(0, i),
        lows: h1Data.lows.slice(0, i),
        closes: h1Data.closes.slice(0, i),
        opens: h1Data.opens.slice(0, i),
        volumes: h1Data.volumes.slice(0, i),
      };
      const m15Slice = {
        highs: m15Data.highs.slice(0, i * 4),
        lows: m15Data.lows.slice(0, i * 4),
        closes: m15Data.closes.slice(0, i * 4),
        opens: m15Data.opens.slice(0, i * 4),
        volumes: m15Data.volumes.slice(0, i * 4),
      };

      if (h4Slice.closes.length < 10) continue;

      // Step 1: H4 trend
      // Backtest: pakai H4 slice sebagai proxy D1 (tidak fetch D1 terpisah)
      const structH4 = analyzePriceActionStructure(h4Slice.highs, h4Slice.lows, h4Slice.closes);
      if (structH4.bias === 'ranging') continue;
      const bias = structH4.bias as 'bullish' | 'bearish';

      // Step 2: H1 zona — gunakan selectBestZoneH1 dengan existing functions
      const currentPrice = h1Slice.closes[h1Slice.closes.length - 1];
      const h1OBs = detectOrderBlocksH1(h1Slice.opens, h1Slice.highs, h1Slice.lows, h1Slice.closes, bias);
      const h1FVGs = detectFVGH1(h1Slice.highs, h1Slice.lows, bias);
      const h1SRLevels = detectSRLevels(h1Slice.highs, h1Slice.lows, h1Slice.closes);
      const h1SnDZones = detectSnDZones(h1Slice.opens, h1Slice.highs, h1Slice.lows, h1Slice.closes);
      const h1Fib = calcFibonacci(h1Slice.highs, h1Slice.lows, h1Slice.closes);
      const selectedZone = selectBestZoneH1(h1OBs, h1FVGs, [], h1SRLevels, h1SnDZones, h1Fib, bias, currentPrice);
      if (!selectedZone) continue;

      // Skip kalau CHoCH H1 terbentuk (konflik)
      const chochH1 = detectCHoCH(h1Slice.highs, h1Slice.lows, h1Slice.closes, bias);
      if (chochH1) continue;

      // Cek apakah harga approaching zona
      const zoneBuffer = (selectedZone.high - selectedZone.low) * 2;
      const nearZone = bias === 'bullish'
        ? currentPrice >= selectedZone.low - zoneBuffer && currentPrice <= selectedZone.high + zoneBuffer
        : currentPrice <= selectedZone.high + zoneBuffer && currentPrice >= selectedZone.low - zoneBuffer;
      if (!nearZone) continue;

      // Kondisi konfirmasi
      const choch15M = detectCHoCH15M(m15Slice.highs, m15Slice.lows, m15Slice.closes, bias);
      const rejection15M = checkRejection15M(
        { low: selectedZone.low, high: selectedZone.high, entryPrice: selectedZone.entryPrice, zoneType: selectedZone.zoneType, refined: false },
        m15Slice.opens, m15Slice.highs, m15Slice.lows, m15Slice.closes, bias, m15Slice.volumes
      );

      // Pattern konfirmasi
      const validPatterns = bias === 'bullish'
        ? ['Bull Flag', 'Ascending Triangle', 'Double Bottom', 'Inverse H&S', 'Falling Wedge', 'Pennant']
        : ['Bear Flag', 'Descending Triangle', 'Double Top', 'Head & Shoulders', 'Rising Wedge', 'Pennant'];
      const h1Patterns = [
        detectBullFlag(h1Slice.highs, h1Slice.lows, h1Slice.closes, h1Slice.volumes),
        detectBearFlag(h1Slice.highs, h1Slice.lows, h1Slice.closes, h1Slice.volumes),
        detectAscendingTriangle(h1Slice.highs, h1Slice.lows, h1Slice.closes),
        detectDescendingTriangle(h1Slice.highs, h1Slice.lows, h1Slice.closes),
        detectDoubleBottom(h1Slice.highs, h1Slice.lows, h1Slice.closes),
        detectDoubleTop(h1Slice.highs, h1Slice.lows, h1Slice.closes),
        detectInverseHS(h1Slice.highs, h1Slice.lows, h1Slice.closes),
        detectHeadAndShoulders(h1Slice.highs, h1Slice.lows, h1Slice.closes),
        detectFallingWedge(h1Slice.highs, h1Slice.lows, h1Slice.closes),
        detectRisingWedge(h1Slice.highs, h1Slice.lows, h1Slice.closes),
        detectPennant(h1Slice.highs, h1Slice.lows, h1Slice.closes, h1Slice.volumes),
      ].filter(p => p && validPatterns.includes(p!.name));
      const hasPattern = h1Patterns.length > 0;

      // Entry & SL/TP
      const entryPrice = rejection15M.confirmed ? rejection15M.entryPrice : selectedZone.entryPrice;
      const atrH1 = calcATR(h1Slice.highs, h1Slice.lows, h1Slice.closes);
      const swingHighs = findSwingHighs(h1Slice.highs, 20);
      const swingLows = findSwingLows(h1Slice.lows, 20);

      let stopLoss: number;
      if (bias === 'bullish') {
        const relevantLows = swingLows.filter(l => l < entryPrice);
        const nearestLow = relevantLows.length > 0 ? Math.max(...relevantLows) : Math.min(...h1Slice.lows.slice(-20));
        stopLoss = nearestLow - atrH1 * 0.2;
      } else {
        const relevantHighs = swingHighs.filter(h => h > entryPrice);
        const nearestHigh = relevantHighs.length > 0 ? Math.min(...relevantHighs) : Math.max(...h1Slice.highs.slice(-20));
        stopLoss = nearestHigh + atrH1 * 0.2;
      }

      const risk = Math.abs(entryPrice - stopLoss);
      if (risk <= 0) continue;
      const dir = bias === 'bullish' ? 1 : -1;
      const takeProfit1 = entryPrice + risk * 1.5 * dir;
      const takeProfit2 = entryPrice + risk * 3.0 * dir;

      // Simulasi trade dengan candle H1 ke depan
      const futureHighs = h1Data.highs.slice(i, i + 48);
      const futureLows = h1Data.lows.slice(i, i + 48);
      const sim = simulateTrade(entryPrice, stopLoss, takeProfit1, takeProfit2, bias, futureHighs, futureLows);

      const entryTime = h1Data.times ? h1Data.times[i] : Date.now();
      const hour = getWIBHour(entryTime);

      sniperTrades.push({
        menu: 'sniper',
        entryTime,
        entryPrice,
        stopLoss,
        takeProfit1,
        takeProfit2,
        bias,
        result: sim.result,
        exitPrice: sim.exitPrice,
        rr: sim.rr,
        hasChoch15M: choch15M.detected,
        hasRejection15M: rejection15M.confirmed,
        hasPattern,
        patternConfidence: hasPattern ? 'MEDIUM' : 'NONE',
        zoneTier: 1, // simplified
        hour,
      });
    }

    result.sniperResult = { ...buildAnalysis(sniperTrades), trades: sniperTrades };
  }

  // ─── BACKTEST MENU 4 (SCALPING) ────────────────────────────────────────────
  if (menu === 'breakout' || menu === 'scalping' || menu === 'both') {
    const scalpingTrades: BacktestTrade[] = [];
    const m15Total = m15Data.closes.length;
    const MIN_M15 = 60;

    for (let j = MIN_M15; j < m15Total - 30; j++) {
      // Slice 15M data sampai titik j
      const h15 = m15Data.highs.slice(0, j);
      const l15 = m15Data.lows.slice(0, j);
      const c15 = m15Data.closes.slice(0, j);
      const o15 = m15Data.opens.slice(0, j);
      const v15 = m15Data.volumes.slice(0, j);

      const currentPrice = c15[c15.length-1];

      // Filter 0: Trend H4 searah — gunakan H4 slice sampai titik ekuivalen
      const h4Idx = Math.floor(j / 4); // index H4 ekuivalen dengan candle 15M ke-j
      if (h4Idx < 10 || h4Idx >= h4Data.closes.length) continue;
      const h4Slice = {
        highs:  h4Data.highs.slice(0, h4Idx),
        lows:   h4Data.lows.slice(0, h4Idx),
        closes: h4Data.closes.slice(0, h4Idx),
      };
      const structH4 = analyzePriceActionStructure(h4Slice.highs, h4Slice.lows, h4Slice.closes);
      if (structH4.bias === 'ranging') continue;
      const h4Bias = structH4.bias as 'bullish' | 'bearish';

      // Filter 1: ATR >= 0.5%
      const atr15M = calcATR(h15.slice(-30), l15.slice(-30), c15.slice(-30));
      if ((atr15M/currentPrice)*100 < 0.5) continue;

      // Filter 2: Bias dari swing 15M
      const swingH = findSwingHighs(h15.slice(-20), 2);
      const swingL = findSwingLows(l15.slice(-20), 2);
      if (swingH.length < 2 || swingL.length < 2) continue;
      const hhF = swingH[swingH.length-1] > swingH[swingH.length-2];
      const hlF = swingL[swingL.length-1] > swingL[swingL.length-2];
      const lhF = swingH[swingH.length-1] < swingH[swingH.length-2];
      const llF = swingL[swingL.length-1] < swingL[swingL.length-2];
      let bias: 'bullish'|'bearish'|null = null;
      if (hhF && hlF) bias='bullish';
      else if (lhF && llF) bias='bearish';
      else if (hhF) bias='bullish';
      else if (llF) bias='bearish';
      if (!bias) continue;

      // Validasi: bias 15M harus searah H4
      if (bias !== h4Bias) continue;

      // Filter 3: Momentum
      const last2 = c15.slice(-2);
      if (bias==='bullish' && last2[1]<=last2[0]) continue;
      if (bias==='bearish' && last2[1]>=last2[0]) continue;

      // Filter 4: OB 15M impulsif approaching
      const lb30H=h15.slice(-30), lb30L=l15.slice(-30), lb30C=c15.slice(-30), lb30O=o15.slice(-30);
      let ob: { low:number; high:number; mid:number }|null = null;
      for (let k=lb30C.length-4; k>=2; k--) {
        const body=Math.abs(lb30C[k]-lb30O[k]);
        const range=lb30H[k]-lb30L[k];
        if (range===0 || body/range<0.6) continue;
        if (bias==='bullish') {
          const dist=currentPrice-lb30H[k];
          if (lb30C[k]<lb30O[k] && lb30H[k]<currentPrice && dist<=atr15M*2) {
            ob={low:lb30L[k],high:lb30H[k],mid:(lb30L[k]+lb30H[k])/2}; break;
          }
        } else {
          const dist=lb30L[k]-currentPrice;
          if (lb30C[k]>lb30O[k] && lb30L[k]>currentPrice && dist<=atr15M*2) {
            ob={low:lb30L[k],high:lb30H[k],mid:(lb30L[k]+lb30H[k])/2}; break;
          }
        }
      }
      if (!ob) continue;

      // Entry, SL, TP
      const entryPrice = ob.mid;
      const buffer = atr15M*0.2;
      const stopLoss = bias==='bullish' ? ob.low-buffer : ob.high+buffer;
      const risk = Math.abs(entryPrice-stopLoss);
      if (risk<=0 || risk>atr15M*3) continue;
      const dir = bias==='bullish'?1:-1;
      const takeProfit1 = entryPrice+risk*1.5*dir;
      const takeProfit2 = entryPrice+risk*2.5*dir;

      // Rejection 15M (info)
      const rejW={opens:o15.slice(-5),highs:h15.slice(-5),lows:l15.slice(-5),closes:c15.slice(-5),volumes:v15.slice(-5)};
      const refRej={low:ob.low,high:ob.high,mid:ob.mid,entryPrice:ob.mid,zoneType:'OB 15M',refined:false};
      const rej15M=checkRejection15M(refRej,rejW.opens,rejW.highs,rejW.lows,rejW.closes,bias,rejW.volumes);

      // Pattern (info)
      const patH=h15.slice(-50),patL=l15.slice(-50),patC=c15.slice(-50),patV=v15.slice(-50);
      const bPat=['Bull Flag','Double Bottom','Falling Wedge'];
      const sPat=['Bear Flag','Double Top','Rising Wedge'];
      const pats=[
        detectBullFlag(patH,patL,patC,patV), detectBearFlag(patH,patL,patC,patV),
        detectDoubleBottom(patH,patL,patC), detectDoubleTop(patH,patL,patC),
      ].filter(p=>p&&(bias==='bullish'?bPat:sPat).includes(p!.name));

      // Simulate: 16 candle 15M ke depan (= 4 jam)
      const futEnd=Math.min(m15Total,j+16);
      const futH=m15Data.highs.slice(j,futEnd);
      const futL=m15Data.lows.slice(j,futEnd);
      if (futH.length<4) continue;
      const sim=simulateTrade(entryPrice,stopLoss,takeProfit1,takeProfit2,bias,futH,futL);
      if (sim.result==='EXPIRED') continue;

      const entryTime=m15Data.times?m15Data.times[j]:Date.now();
      const hour=getWIBHour(entryTime);

      scalpingTrades.push({
        menu:'scalping', entryTime, entryPrice, stopLoss, takeProfit1, takeProfit2, bias,
        result:sim.result, exitPrice:sim.exitPrice, rr:sim.rr,
        hasChoch15M:true,
        hasRejection15M:rej15M.confirmed,
        hasPattern:pats.length>0,
        patternConfidence:pats.length>0?'MEDIUM':'NONE',
        zoneTier:1, hour,
      });
    }

    result.breakoutResult = { ...buildAnalysis(scalpingTrades), trades: scalpingTrades };
    result.scalpingResult = result.breakoutResult;
  }


  // Comparison
  if (result.sniperResult && result.breakoutResult) {
    const sWR = result.sniperResult.winRate;
    const bWR = result.breakoutResult.winRate;
    const better = sWR > bWR + 5 ? 'sniper' : bWR > sWR + 5 ? 'breakout' : 'equal';

    // Cari filter paling impactful dari semua trades
    const allBreakdowns = [result.sniperResult.breakdown, result.breakoutResult.breakdown];
    let maxDiff = 0;
    let mostImpactful = 'CHoCH 15M';
    const checks = [
      ['withChoch15M', 'withoutChoch15M', 'CHoCH 15M'],
      ['withRejection15M', 'withoutRejection15M', 'Rejection 15M'],
      ['withPattern', 'withoutPattern', 'Pattern Konfirmasi'],
      ['tier1to2', 'tier3plus', 'Zona Tier 1-2'],
      ['londonNY', 'asian', 'Sesi London/NY'],
    ] as const;

    for (const [with_, without_, label] of checks) {
      for (const bd of allBreakdowns) {
        const diff = Math.abs((bd as any)[with_].winRate - (bd as any)[without_].winRate);
        if (diff > maxDiff) { maxDiff = diff; mostImpactful = label; }
      }
    }

    result.comparison = {
      better,
      sniperWinRate: sWR,
      breakoutWinRate: bWR,
      mostImpactfulFilter: mostImpactful,
    };
  }

  return result;
}